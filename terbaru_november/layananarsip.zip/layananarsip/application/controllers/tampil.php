 <?php  
  class Tampil extends CI_Controller{  
   function __construct(){  
    parent::__construct();  
    $this->load->helper(array('url', 'form'));  
    $this->load->model('m_tampil');  
   }  
   function lihat(){  
    $data['data_buku'] = $this->m_tampil->m_lihat();  
    $this->load->view('v_lihat', $data);  
   }  
  }  
 ?>  