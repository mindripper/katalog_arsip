<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Layanan extends CI_Controller {

	function __construct(){  
    parent::__construct();  
    $this->load->library('session');
    $this->load->helper(array('form','url'));  
    $this->load->model('Models');  
    $this->load->database(); 
   }  

   public function index()
      {
        $this->load->view('menu');
      }  

    public function index2(){
        $this->session->set_flashdata('error', 'Session telah dihapus');
        $this->load->view('menu');
    }

    public function admin(){
        $this->load->view('admin');
    }

    public function load_daftar(){
    	$this->load->view('formawal');
    }

    public function load_kunjungan(){
        $this->load->view('formkunjungan');
    }

    public function view_kuesioner1(){
        $this->load->view('kuesioner1');
    }

    public function view_kuesioner2(){
        $this->load->view('kuesioner2');
    }

    public function view_kuesioner3(){
        $this->load->view('kuesioner3');
    }


    public function view_kuesioner4(){
        $this->load->view('kuesioner4');
    }


    public function view_kuesioner5(){
        $this->load->view('kuesioner5');
    }


    public function view_kuesioner6(){
        $this->load->view('kuesioner6');
    }


    public function view_kuesioner7(){
        $this->load->view('kuesioner7');
    }


    public function view_kuesioner8(){
        $this->load->view('kuesioner8');
    }


    public function view_kuesioner9(){
        $this->load->view('kuesioner9');
    }


    public function view_kuesioner10(){
        $this->load->view('kuesioner10');
    }

    public function menu_masuk(){
    	$id=$this->input->post("no_id");
    	$result=$this->Models->masuk($id);
    	$id2[0]=$this->input->post("no_id");

    	if($result)
    	{
    		$session_data = array('nama' => $result[0]->nama_anggota,'id' =>$result[0]->identitas_pengguna);
			$this->session->set_userdata($session_data);
			//redirect(base_url().'layanan/load_kunjungan');
            redirect(base_url().'layanan/load_kunjungan');
    	}
    	else
    	{
    		$session_data = array('nama' => $id2[0]);
			$this->session->set_userdata($session_data);

			redirect(base_url().'layanan/load_daftar');
    	}
    }

    public function form_daftar(){
        $id2[0]=$this->input->post('id');
        $id2[1]=$this->input->post('nama');

        $data=array(
            'nama_anggota'=>$this->input->post('nama'),
            'identitas_pengguna'=>$this->input->post('id'),
            'jk_anggota'=>$this->input->post('jk'),
            'tanggal_lahir'=>$this->input->post('ttl'),
            'umur_anggota'=>$this->input->post('usia'),
            'telepon_pengguna'=>$this->input->post('telp'),
            'kewarganegaraan_anggota'=>$this->input->post('kewarganegaraan'),
            'asal_pengguna'=>$this->input->post('alamat'),
            'pendidikan_pengguna'=>$this->input->post('pendidikan'),
            'profesi_pengguna'=>$this->input->post('profesi'),
            'tempat_studi'=>$this->input->post('tempatstudi'),
            'program_studi'=>$this->input->post('prodi'));

        $result=$this->db->insert('anggota', $data);
        if($result)
        {
            $session_data = array('id' => $id2[0], 'nama'=>$id2[1]);
            $this->session->set_userdata($session_data);
            redirect(base_url().'layanan/load_kunjungan');
        }
        else
        {
            $this->session->set_flashdata('error', 'Data yang anda masukkan salah');
            redirect(base_url().'layanan/form_daftar');
        }
    }

    public function form_kunjungan(){
        $id2[0]=$this->input->post("no_id");
        $kategori[0]=$this->input->post('kategorii');
        $time=date("Y-m-d");
        $data=array(
            'indeks_anggota_fk'=>$id2[0],
            'tanggal'=>$time,
            'keperluan_kunjungan'=>$this->input->post('kepentingan'),
            'kategori_kunjungan'=>$this->input->post('kategorii'),
            'jumlah_kunjungan'=>$this->input->post('kunjungan'),
            'fokus_kunjungan'=>$this->input->post('fokus'),
            'media_kunjungan'=>$this->input->post('media'),
            'proyeksi_kunjungan'=>$this->input->post('proyeksi'));

        $result=$this->db->insert('kunjungan', $data);
        if($result)
        {
            $session_data = array('id' => $id2[0], 'kategori'=>$kategori[0]);
            $this->session->set_userdata($session_data);
            redirect(base_url().'layanan/view_kuesioner1');
        }
        else
        {
            $this->session->set_flashdata('error', 'Data yang anda masukkan salah');
            redirect(base_url().'layanan/form_daftar');
        }
    }

    public function kuesioner1(){
        print_r ($id2, $kategori);
        $id2[0]=$this->input->post("no_id");
        $time=date("Y-m-d");
        $data=array(
            'id_anggota_fk'=>$this->input->post('no_id'),
            'tanggal'=>$time,
            'jawaban1'=>$this->input->post('question-1-answers'),
            'jawaban2'=>$this->input->post('question-2-answers'),
            'jawaban3'=>$this->input->post('question-3-answers'),
            'jawaban4'=>$this->input->post('question-4-answers'),
            'jawaban5'=>$this->input->post('question-5-answers')
            );

        $result=$this->db->insert('kategori1', $data);
        if($result)
        {
            $session_data = array('nama' => $id2[0]);
            $this->session->set_userdata($session_data);
            redirect(base_url().'layanan/view_kuesioner2');
        }
        else
        {
            $this->session->set_flashdata('error', 'Data yang anda masukkan salah');
            redirect(base_url().'layanan/view_kuesioner1');
        }
    }

    public function kuesioner2(){
        $id2[0]=$this->input->post("no_id");
        $time=date("Y-m-d");
        $data=array(
            'id_anggota_fk'=>$this->input->post('no_id'),
            'tanggal'=>$time,
            'jawaban1'=>$this->input->post('question-1-answers'),
            'jawaban2'=>$this->input->post('question-2-answers'),
            'jawaban3'=>$this->input->post('question-3-answers'),
            'jawaban4'=>$this->input->post('question-4-answers'),
            'jawaban5'=>$this->input->post('question-5-answers'),
            'jawaban6'=>$this->input->post('question-6-answers'),
            'jawaban7'=>$this->input->post('question-7-answers'),
            'jawaban8'=>$this->input->post('question-8-answers'),
            'jawaban9'=>$this->input->post('question-9-answers'),
            'jawaban10'=>$this->input->post('question-10-answers'),
            'jawaban11'=>$this->input->post('question-11-answers'),
            'jawaban12'=>$this->input->post('question-12-answers'),
            'jawaban13'=>$this->input->post('question-13-answers')
            );

        $result=$this->db->insert('kategori2', $data);
        if($result)
        {
            $session_data = array('nama' => $id2[0]);
            $this->session->set_userdata($session_data);
            redirect(base_url().'layanan/view_kuesioner3');
        }
        else
        {
            $this->session->set_flashdata('error', 'Data yang anda masukkan salah');
            redirect(base_url().'layanan/kuesioner2');
        }
    }

    public function kuesioner3(){
        $id2[0]=$this->input->post("no_id");
        $time=date("Y-m-d");
        $data=array(
            'id_anggota_fk'=>$this->input->post('no_id'),
            'tanggal'=>$time,
            'jawaban1'=>$this->input->post('question-1-answers'),
            'jawaban2'=>$this->input->post('question-2-answers'),
            'jawaban3'=>$this->input->post('question-3-answers'),
            'jawaban4'=>$this->input->post('question-4-answers'),
            'jawaban5'=>$this->input->post('question-5-answers'),
            'jawaban6'=>$this->input->post('question-6-answers'),
            'jawaban7'=>$this->input->post('question-7-answers'),
            'jawaban8'=>$this->input->post('question-8-answers'),
            'jawaban9'=>$this->input->post('question-9-answers')
            );

        $result=$this->db->insert('kategori3', $data);
        if($result)
        {
            $session_data = array('nama' => $id2[0]);
            $this->session->set_userdata($session_data);
            redirect(base_url().'layanan/view_kuesioner4');
        }
        else
        {
            $this->session->set_flashdata('error', 'Data yang anda masukkan salah');
            redirect(base_url().'layanan/view_kuesioner3');
        }
    }

    public function kuesioner4(){
        $id2[0]=$this->input->post("no_id");
        $time=date("Y-m-d");
        $data=array(
            'id_anggota_fk'=>$this->input->post('no_id'),
            'tanggal'=>$time,
            'jawaban1'=>$this->input->post('question-1-answers'),
            'jawaban2'=>$this->input->post('question-2-answers'),
            'jawaban3'=>$this->input->post('question-3-answers'),
            'jawaban4'=>$this->input->post('question-4-answers')
            );

        $result=$this->db->insert('kategori4', $data);
        if($result)
        {
            $session_data = array('nama' => $id2[0]);
            $this->session->set_userdata($session_data);
            redirect(base_url().'layanan/view_kuesioner5');
        }
        else
        {
            $this->session->set_flashdata('error', 'Data yang anda masukkan salah');
            redirect(base_url().'layanan/view_kuesioner4');
        }
    }

    public function kuesioner5(){
        $id2[0]=$this->input->post("no_id");
        $time=date("Y-m-d");
        $data=array(
            'id_anggota_fk'=>$this->input->post('no_id'),
            'tanggal'=>$time,
            'jawaban1'=>$this->input->post('question-1-answers'),
            'jawaban2'=>$this->input->post('question-2-answers'),
            'jawaban3'=>$this->input->post('question-3-answers'),
            'jawaban4'=>$this->input->post('question-4-answers'),
            'jawaban5'=>$this->input->post('question-5-answers'),
            'jawaban6'=>$this->input->post('question-6-answers'),
            'jawaban7'=>$this->input->post('question-7-answers'),
            'jawaban8'=>$this->input->post('question-8-answers'),
            'jawaban9'=>$this->input->post('question-9-answers'),
            'jawaban10'=>$this->input->post('question-10-answers'),
            'jawaban11'=>$this->input->post('question-11-answers')
            );

        $result=$this->db->insert('kategori5', $data);
        if($result)
        {
            $session_data = array('nama' => $id2[0]);
            $this->session->set_userdata($session_data);
            redirect(base_url().'layanan/view_kuesioner6');
        }
        else
        {
            $this->session->set_flashdata('error', 'Data yang anda masukkan salah');
            redirect(base_url().'layanan/view_kuesioner5');
        }
    }

    public function kuesioner6(){
        $id2[0]=$this->input->post("no_id");
        $time=date("Y-m-d");
        $data=array(
            'id_anggota_fk'=>$this->input->post('no_id'),
            'tanggal'=>$time,
            'jawaban1'=>$this->input->post('question-1-answers'),
            'jawaban2'=>$this->input->post('question-2-answers'),
            'jawaban3'=>$this->input->post('question-3-answers'),
            'jawaban4'=>$this->input->post('question-4-answers')
            );

        $result=$this->db->insert('kategori6', $data);
        if($result)
        {
            $session_data = array('nama' => $id2[0]);
            $this->session->set_userdata($session_data);
            redirect(base_url().'layanan/view_kuesioner7');
        }
        else
        {
            $this->session->set_flashdata('error', 'Data yang anda masukkan salah');
            redirect(base_url().'layanan/view_kuesioner6');
        }
    }

    public function kuesioner7(){
        $id2[0]=$this->input->post("no_id");
        $time=date("Y-m-d");
        $data=array(
            'id_anggota_fk'=>$this->input->post('no_id'),
            'tanggal'=>$time,
            'jawaban1'=>$this->input->post('question-1-answers'),
            'jawaban2'=>$this->input->post('question-2-answers'),
            'jawaban3'=>$this->input->post('question-3-answers'),
            'jawaban4'=>$this->input->post('question-4-answers'),
            'jawaban5'=>$this->input->post('question-5-answers'),
            'jawaban6'=>$this->input->post('question-6-answers'),
            'jawaban7'=>$this->input->post('question-7-answers'),
            'jawaban8'=>$this->input->post('question-8-answers'),
            'jawaban9'=>$this->input->post('question-9-answers'),
            'jawaban10'=>$this->input->post('question10-answers'),
            'jawaban11'=>$this->input->post('question-11-answers'),
            'jawaban12'=>$this->input->post('question-12-answers'),
            'jawaban13'=>$this->input->post('question-13-answers'),
            'jawaban14'=>$this->input->post('question-14-answers'),
            'jawaban15'=>$this->input->post('question-15-answers'),
            );

        $result=$this->db->insert('kategori7', $data);
        if($result)
        {
            $session_data = array('nama' => $id2[0]);
            $this->session->set_userdata($session_data);
            redirect(base_url().'layanan/kuesioner8');
        }
        else
        {
            $this->session->set_flashdata('error', 'Data yang anda masukkan salah');
            redirect(base_url().'layanan/kuesioner7');
        }
    }

    public function kuesioner8(){
        $id2[0]=$this->input->post("no_id");
        $time=date("Y-m-d");
        $data=array(
            'id_anggota_fk'=>$this->input->post('no_id'),
            'tanggal'=>$time,
            'jawaban1'=>$this->input->post('question-1-answers'),
            'jawaban2'=>$this->input->post('question-2-answers'),
            'jawaban3'=>$this->input->post('question-3-answers')
            );

        $result=$this->db->insert('kategori8', $data);
        if($result)
        {
            $session_data = array('nama' => $id2[0]);
            $this->session->set_userdata($session_data);
            redirect(base_url().'layanan/view_kuesioner9');
        }
        else
        {
            $this->session->set_flashdata('error', 'Data yang anda masukkan salah');
            redirect(base_url().'layanan/view_kuesioner8');
        }
    }

    public function kuesioner9(){
        $id2[0]=$this->input->post("no_id");
        $time=date("Y-m-d");
        $data=array(
            'id_anggota_fk'=>$this->input->post('no_id'),
            'tanggal'=>$time,
            'jawaban1'=>$this->input->post('question-1-answers'),
            'jawaban2'=>$this->input->post('question-2-answers'),
            'jawaban3'=>$this->input->post('question-3-answers'),
            'jawaban4'=>$this->input->post('question-4-answers'),
            'jawaban5'=>$this->input->post('question-5-answers'),
            'jawaban6'=>$this->input->post('question-6-answers'),
            'jawaban7'=>$this->input->post('question-7-answers'),
            'jawaban8'=>$this->input->post('question-8-answers'),
            'jawaban9'=>$this->input->post('question-9-answers')
            );

        $result=$this->db->insert('kategori9', $data);
        if($result)
        {
            $session_data = array('nama' => $id2[0]);
            $this->session->set_userdata($session_data);
            redirect(base_url().'layanan/view_kuesioner10');
        }
        else
        {
            $this->session->set_flashdata('error', 'Data yang anda masukkan salah');
            redirect(base_url().'layanan/view_kategori9');
        }
    }

    public function kuesioner10(){
        $id2[0]=$this->input->post("no_id");
        $time=date("Y-m-d");
        $data=array(
            'id_anggota_fk'=>$this->input->post('no_id'),
            'tanggal'=>$time,
            'jawaban1'=>$this->input->post('question-1-answers'),
            'jawaban2'=>$this->input->post('question-2-answers'),
            'jawaban3'=>$this->input->post('question-3-answers')
            );

        $result=$this->db->insert('kategori10', $data);
        if($result)
        {
            $session_data = array('nama' => $id2[0]);
            $this->session->set_userdata($session_data);
            redirect(base_url().'layanan/view_selesai');
        }
        else
        {
            $this->session->set_flashdata('error', 'Data yang anda masukkan salah');
            redirect(base_url().'layanan/view_kategori10');
        }
    }

    public function view_selesai(){
        $this->load->view('selesai');
        $this->session->set_flashdata('error', 'Kembali Ke Menu Utama');
    }
    
}