<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	function __construct(){  
    parent::__construct();  
    $this->load->library('session');
    $this->load->helper(array('form','url'));  
    $this->load->model('Models');  
    $this->load->database();
    
   }  

	public function index()
      {
        $this->load->view('menu');
      }  

    public function load_daftar(){
        $data= $this->session->all_userdata();
        print_r($data);
        echo "Last asdasdas: ".($_SESSION['__ci_last_regenerate']);

    	$this->load->view('formawal');
    }

    public function load_kunjungan(){
        $data= $this->session->all_userdata();
        print_r($data);

        $this->load->view('formkunjungan');
    }
    public function logout(){

    $this->session->sess_destroy();
    echo 'log out sukses';
    }


    public function menu_masuk(){
    	$id=$this->input->post("no_id");
    	$result=$this->Models->masuk($id);

    	if($result)
    	{
    		$session_data = array('nama' => $result[0]->nama_anggota);
			$this->session->set_userdata($session_data);
			redirect(base_url().'Welcome/load_kunjungan');
    	}
    	else
    	{
    		$session_data = array('id' => $id);
    		$this->session->set_userdata($id);
    		redirect(base_url().'Welcome/load_daftar/',$id);
    	}
    }

    public function form_daftar(){
        $data=array(
            'identitas_pengguna'=>$this->input->post('id'),
            'nama_anggota'=>$this->input->post('nama'),
            'jk_anggota'=>$this->input->post('jk'),
            'tanggal_lahir'=>$this->input->post('ttl'),
            'umur_anggota'=>$this->input->post('usia'),
            'telepon_pengguna'=>$this->input->post('telp'),
            'kewarganegaraan_anggota'=>$this->input->post('kewarganegaraan'),
            'asal_pengguna'=>$this->input->post('alamat'),
            'pendidikan_pengguna'=>$this->input->post('pendidikan'),
            'profesi_pengguna'=>$this->input->post('profesi'),
            'tempat_studi'=>$this->input->post('tempat'),
            'program_studi'=>$this->input->post('prodi'));

        $result=$this->db->insert('anggota', $data);
        if($result)
        {
            redirect(base_url().'welcome/index');
        }
        else
        {
            $this->session->set_flashdata('error', 'Data yang anda masukkan salah');
            redirect(base_url().'welcome/form_daftar');
        }
    }

    public function kuesioner1(){
        $indeks="12423423";
        $data=array(
            'indeks_anggota'=>$indeks,
            'indeks_pertanyaan'=>$this->input->post('p1'),
            'jawaban_survey'=>$this->input->post('question-1-answers'));

        $result=$this->db->insert('rekap_survey',$data);

    if ($result){
        redirect(base_url().'welcome/index');
    }

    }




}

