<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

  function __construct(){  
    parent::__construct();  
    $this->load->library('session');
    $this->load->helper(array('form','url'));  
    $this->load->model('Model2');
    $this->load->model('Models');  
    $this->load->database(); 
   }

   public function index(){
    $this->load->view('admin');
   }

    public function index2(){
        $this->session->set_flashdata('error', 'Session telah dihapus');
        $this->load->view('admin');
    }

    public function login(){
      $username=$this->input->post("username");
      $password=$this->input->post("password");
      $result=$this->Models->login($username, $password);
      

      if($result)
      {
      $time=date("Y-m-d");
      $session_data = array('tanggal' => $result[0]->$time);
      $this->session->set_userdata($session_data);
      redirect(base_url().'admin/index');
      }
      else
      {
      redirect(base_url().'layanan/index');
      }
    }

  public function get_menu(){
    $bulan=$this->input->post('bulan');
    $tahun=$this->input->post('tahun');
    $pilihan=$this->input->post('select');
    $month = date('m',strtotime($bulan));
    $dateObj   = DateTime::createFromFormat('!m', $bulan);
    $monthName = $dateObj->format('F');
    $b[0]=$monthName;
    $b[1]=$tahun;
    $b[2]=$bulan;

    

    if($pilihan=="1"){
      $usia=$this->Model2->get_usia();
      $jk=$this->Model2->get_jk();
      $kewarganegaraaan=$this->Model2->get_kwn();
      $pend_t=$this->Model2->get_pt();
      $profesi=$this->Model2->get_prof();
      $t_studi=$this->Model2->get_ts();
      $data=array(
        'usia'=>$usia,
        'jk'=>$jk,
        'kwn'=>$kewarganegaraaan,
        'pt'=>$pend_t,
        'prof'=>$profesi,
        'tmpstudi'=>$t_studi);

      $session_data = array('bulan' => $b[0], 'tahun'=>$b[1], 'bulan2'=>$b[2]);
      $this->session->set_userdata($session_data);
      
      $this->load->view('grafik1', $data);
     }

    else if($pilihan=="2"){
      $v_keperluan=$this->Model2->kunj_kep($bulan, $tahun);
      $v_media=$this->Model2->kunj_media($bulan, $tahun);
      $v_kategori=$this->Model2->kunj_kategori($bulan, $tahun);
      $v_fokus=$this->Model2->kunj_fokus($bulan, $tahun);
      $v_jumlah=$this->Model2->kunj_jumlah($bulan, $tahun);
      $v_proyeksi=$this->Model2->kunj_proyeksi($bulan, $tahun);
      //print_r($v_keperluan);

      $data=array(
        'keperluan'=>$v_keperluan,
        'media'=>$v_media,
        'kategori'=>$v_kategori,
        'fokus'=>$v_fokus,
        'jumlah'=>$v_jumlah,
        'proyeksi'=>$v_proyeksi,
        'bulan'=>$bulan,
        'tahun'=>$tahun);
      $this->session->set_userdata($data);
      $session_data = array('bulan' => $b[0], 'tahun'=>$b[1], 'bulan2'=>$b[2]);
      $this->session->set_userdata($session_data);
      $this->load->view('grafik2',$data);
    }

    else if ($pilihan=="3") {
    $kat1=$this->Model2->jumlah1($bulan, $tahun);
    $kat2=$this->Model2->jumlah2($bulan, $tahun);
    $kat3=$this->Model2->jumlah3($bulan, $tahun);
    $kat4=$this->Model2->jumlah4($bulan, $tahun);
    $kat5=$this->Model2->jumlah5($bulan, $tahun);
    $kat6=$this->Model2->jumlah6($bulan, $tahun);
    $kat7=$this->Model2->jumlah7($bulan, $tahun);
    $kat8=$this->Model2->jumlah8($bulan, $tahun);
    $kat9=$this->Model2->jumlah9($bulan, $tahun);
    $kat10=$this->Model2->jumlah10($bulan, $tahun);
    //tugas yg belum mengeprint bulan dalam grafik. kan value yang disimpan berupa int (misal: 08) gmana cara econvert ke bulan (String)
    $data=array(
    'k1'=>$kat1,
      'k2'=>$kat2,
      'k3'=>$kat3,
      'k4'=>$kat4,
      'k5'=>$kat5,
      'k6'=>$kat6,
      'k6'=>$kat6,
      'k7'=>$kat7,
      'k8'=>$kat8,
      'k9'=>$kat9,
      'k10'=>$kat10);

    $session_data = array('bulan' => $b[0], 'tahun'=>$b[1], 'bulan2'=>$b[2]);
      $this->session->set_userdata($session_data);

      $this->load->view('grafik3', $data,$tahun);
    }
  }

  public function print1(){
      $usia=$this->Model2->get_usia();
      $jk=$this->Model2->get_jk();
      $kewarganegaraaan=$this->Model2->get_kwn();
      $pend_t=$this->Model2->get_pt();
      $profesi=$this->Model2->get_prof();
      $t_studi=$this->Model2->get_ts();
      $data=array(
        'usia'=>$usia,
        'jk'=>$jk,
        'kwn'=>$kewarganegaraaan,
        'pt'=>$pend_t,
        'prof'=>$profesi,
        'tmpstudi'=>$t_studi);

      //$session_data = array('bulan' => $b[0], 'tahun'=>$b[1]);
      //$this->session->set_userdata($session_data);
      $this->load->view('print-grafik1a',$data);
  }

   public function print2(){
      $usia=$this->Model2->get_usia();
      $jk=$this->Model2->get_jk();
      $kewarganegaraaan=$this->Model2->get_kwn();
      $pend_t=$this->Model2->get_pt();
      $profesi=$this->Model2->get_prof();
      $t_studi=$this->Model2->get_ts();
      $data=array(
        'usia'=>$usia,
        'jk'=>$jk,
        'kwn'=>$kewarganegaraaan,
        'pt'=>$pend_t,
        'prof'=>$profesi,
        'tmpstudi'=>$t_studi);

      //$session_data = array('bulan' => $b[0], 'tahun'=>$b[1]);
      //$this->session->set_userdata($session_data);
    $this->load->view('print-grafik1b',$data);
  }

   public function print3(){
    $bulan=$this->session->userdata('bulan');
    $tahun=$this->session->userdata('tahun');
    $no_bulan=$this->session->userdata('bulan2');
   
    
     $v_keperluan=$this->Model2->kunj_kep($no_bulan, $tahun);
      $v_media=$this->Model2->kunj_media($no_bulan, $tahun);
      $v_kategori=$this->Model2->kunj_kategori($no_bulan, $tahun);
      $v_fokus=$this->Model2->kunj_fokus($no_bulan, $tahun);
      $v_jumlah=$this->Model2->kunj_jumlah($no_bulan, $tahun);
      $v_proyeksi=$this->Model2->kunj_proyeksi($no_bulan, $tahun);
     
      $data=array(
        'keperluan'=>$v_keperluan,
        'media'=>$v_media,
        'kategori'=>$v_kategori,
        'fokus'=>$v_fokus,
        'jumlah'=>$v_jumlah,
        'proyeksi'=>$v_proyeksi,
        'bulan'=>$bulan,
        'tahun'=>$tahun);
      // $b[0]=$bulan;
    //$b[1]=$tahun;
      //$session_data = array('bulan' => $b[0], 'tahun'=>$b[1]);
      $this->session->set_userdata($data);
    $this->load->view('print-grafik2a',$data);
  }

   public function print4(){
    $bulan=$this->session->userdata('bulan');
    $tahun=$this->session->userdata('tahun');
    $no_bulan=$this->session->userdata('bulan2');
    $b[0]=$bulan;
    $b[1]=$tahun;
     $v_keperluan=$this->Model2->kunj_kep($no_bulan, $tahun);
      $v_media=$this->Model2->kunj_media($no_bulan, $tahun);
      $v_kategori=$this->Model2->kunj_kategori($no_bulan, $tahun);
      $v_fokus=$this->Model2->kunj_fokus($no_bulan, $tahun);
      $v_jumlah=$this->Model2->kunj_jumlah($no_bulan, $tahun);
      $v_proyeksi=$this->Model2->kunj_proyeksi($no_bulan, $tahun);

      $data=array(
        'keperluan'=>$v_keperluan,
        'media'=>$v_media,
        'kategori'=>$v_kategori,
        'fokus'=>$v_fokus,
        'jumlah'=>$v_jumlah,
        'proyeksi'=>$v_proyeksi,
        'bulan'=>$bulan,
        'tahun'=>$tahun);

      $session_data = array('bulan' => $b[0], 'tahun'=>$b[1]);
      $this->session->set_userdata($session_data);
    $this->load->view('print-grafik2b',$data);
  }

   public function print5(){
    $bulan=$this->session->userdata('bulan');
    $tahun=$this->session->userdata('tahun');
    $no_bulan=$this->session->userdata('bulan2');
    $kat1=$this->Model2->jumlah1($no_bulan, $tahun);
    $kat2=$this->Model2->jumlah2($no_bulan, $tahun);
    $kat3=$this->Model2->jumlah3($no_bulan, $tahun);
    $kat4=$this->Model2->jumlah4($no_bulan, $tahun);
    $kat5=$this->Model2->jumlah5($no_bulan, $tahun);
    $kat6=$this->Model2->jumlah6($no_bulan, $tahun);
    $kat7=$this->Model2->jumlah7($no_bulan, $tahun);
    $kat8=$this->Model2->jumlah8($no_bulan, $tahun);
    $kat9=$this->Model2->jumlah9($no_bulan, $tahun);
    $kat10=$this->Model2->jumlah10($no_bulan, $tahun);
    //tugas yg belum mengeprint bulan dalam grafik. kan value yang disimpan berupa int (misal: 08) gmana cara econvert ke bulan (String)
    $data=array(
    'k1'=>$kat1,
      'k2'=>$kat2,
      'k3'=>$kat3,
      'k4'=>$kat4,
      'k5'=>$kat5,
      'k6'=>$kat6,
      'k6'=>$kat6,
      'k7'=>$kat7,
      'k8'=>$kat8,
      'k9'=>$kat9,
      'k10'=>$kat10);
    $b[0]=$bulan;
    $b[1]=$tahun;

    $session_data = array('bulan' => $b[0], 'tahun'=>$b[1]);
    $this->session->set_userdata($session_data);
    $this->load->view('print-grafik3a', $data);
  }

   public function print6(){
     $bulan=$this->session->userdata('bulan');
    $tahun=$this->session->userdata('tahun');
    $no_bulan=$this->session->userdata('bulan2');
    $kat1=$this->Model2->jumlah1($no_bulan, $tahun);
    $kat2=$this->Model2->jumlah2($no_bulan, $tahun);
    $kat3=$this->Model2->jumlah3($no_bulan, $tahun);
    $kat4=$this->Model2->jumlah4($no_bulan, $tahun);
    $kat5=$this->Model2->jumlah5($no_bulan, $tahun);
    $kat6=$this->Model2->jumlah6($no_bulan, $tahun);
    $kat7=$this->Model2->jumlah7($no_bulan, $tahun);
    $kat8=$this->Model2->jumlah8($no_bulan, $tahun);
    $kat9=$this->Model2->jumlah9($no_bulan, $tahun);
    $kat10=$this->Model2->jumlah10($no_bulan, $tahun);
    //tugas yg belum mengeprint bulan dalam grafik. kan value yang disimpan berupa int (misal: 08) gmana cara econvert ke bulan (String)
    $data=array(
    'k1'=>$kat1,
      'k2'=>$kat2,
      'k3'=>$kat3,
      'k4'=>$kat4,
      'k5'=>$kat5,
      'k6'=>$kat6,
      'k6'=>$kat6,
      'k7'=>$kat7,
      'k8'=>$kat8,
      'k9'=>$kat9,
      'k10'=>$kat10);
    $b[0]=$bulan;
    $b[1]=$tahun;

    $session_data = array('bulan' => $b[0], 'tahun'=>$b[1]);
      $this->session->set_userdata($session_data);
    $this->load->view('print-grafik3b', $data);
  }

 

}
?>