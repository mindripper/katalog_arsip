<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Layanan Kearsipan</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/grafik.css">
  <link href='https://fonts.googleapis.com/css?family=Anton' rel='stylesheet'>
  <link href='https://fonts.googleapis.com/css?family=Fjalla+One' rel='stylesheet'>
</head>

<body>
<?php
  $flag=1;
  foreach ($keperluan as $tmp) {
    if($tmp->keperluan_kunjungan == 'Penulisan Skripsi/Tesis/Disertasi'){
     $a1=$tmp->jumlah_kk;
     $flag = 0;
    }
  }
  if($flag) $a1=0;
  ?>

  <?php
  $flag=1;
  foreach ($keperluan as $tmp) {
    if($tmp->keperluan_kunjungan == 'Penulisan Tugas Kuliah'){
     $a2=$tmp->jumlah_kk;
     $flag = 0;
    }
  }
  if($flag) $a2=0;
  ?>

  <?php
  $flag=1;
  foreach ($keperluan as $tmp) {
    if($tmp->keperluan_kunjungan == 'Pembuktian Hukum'){
     $a3=$tmp->jumlah_kk;
     $flag = 0;
    }
  }
  if($flag) $a3=0;
  ?>

    <?php
  $flag=1;
  foreach ($keperluan as $tmp) {
    if($tmp->keperluan_kunjungan == 'Penulisan Sejarah'){
     $a4=$tmp->jumlah_kk;
     $flag = 0;
    }
  }
  if($flag) $a4=0;
  ?>

  <?php
  $flag=1;
  foreach ($keperluan as $tmp) {
    if($tmp->keperluan_kunjungan == 'Penelusuran Silsilah Keluarga'){
     $a5=$tmp->jumlah_kk;
     $flag = 0;
    }
  }
  if($flag) $a5=0;
  ?>

  <?php
  $flag=1;
  foreach ($keperluan as $tmp) {
    if($tmp->keperluan_kunjungan == 'Kedinasan'){
     $a6=$tmp->jumlah_kk;
     $flag = 0;
    }
  }
  if($flag) $a6=0;
  ?>

  <?php
  $flag=1;
  foreach ($keperluan as $tmp) {
    if($tmp->keperluan_kunjungan == 'Lain-lain'){
     $a7=$tmp->jumlah_kk;
     $flag = 0;
    }
  }
  if($flag) $a7=0;
  ?>

<!-- perhitungan fokus kunjungan -->
<?php
  $flag=1;
  foreach ($fokus as $tmp) {
    if($tmp->fokus_kunjungan == 'Arsip sebelum 1900'){
     $b1=$tmp->jumlah_kf;
     $flag = 0;
    }
  }
  if($flag) $b1=0;
  ?>

  <?php
  $flag=1;
  foreach ($fokus as $tmp) {
    if($tmp->fokus_kunjungan == 'Arsip 1901 - 1945'){
     $b2=$tmp->jumlah_kf;
     $flag = 0;
    }
  }
  if($flag) $b2=0;
  ?>

  <?php
  $flag=1;
  foreach ($fokus as $tmp) {
    if($tmp->fokus_kunjungan == 'Arsip 1946 - 1965'){
     $b3=$tmp->jumlah_kf;
     $flag = 0;
    }
  }
  if($flag) $b3=0;
  ?>

  <?php
  $flag=1;
  foreach ($fokus as $tmp) {
    if($tmp->fokus_kunjungan == 'Arsip 1966 - 1985'){
     $b4=$tmp->jumlah_kf;
     $flag = 0;
    }
  }
  if($flag) $b4=0;
  ?>

  <?php
  $flag=1;
  foreach ($fokus as $tmp) {
    if($tmp->fokus_kunjungan == 'Arsip 1986 - Sekarang'){
     $b5=$tmp->jumlah_kf;
     $flag = 0;
    }
  }
  if($flag) $b5=0;
  ?>

<!-- perhitungan kategori kunjungan -->
<?php
  $flag=1;
  foreach ($kategori as $tmp) {
    if($tmp->kategori_kunjungan == 'Umum'){
     $c1=$tmp->jumlah_kat;
     $flag = 0;
    }
  }
  if($flag) $c1=0;
  ?>

  <?php
  $flag=1;
  foreach ($kategori as $tmp) {
    if($tmp->kategori_kunjungan == 'Secretary Oost Java'){
     $c2=$tmp->jumlah_kat;
     $flag = 0;
    }
  }
  if($flag) $c2=0;
  ?>

  <?php
  $flag=1;
  foreach ($kategori as $tmp) {
    if($tmp->kategori_kunjungan == 'Lembaga Vertikal'){
     $c3=$tmp->jumlah_kat;
     $flag = 0;
    }
  }
  if($flag) $c3=0;
  ?>

  <?php
  $flag=1;
  foreach ($kategori as $tmp) {
    if($tmp->kategori_kunjungan == 'Organisasi Perangkat Daerah'){
     $c4=$tmp->jumlah_kat;
     $flag = 0;
    }
  }
  if($flag) $c4=0;
  ?>

  <?php
  $flag=1;
  foreach ($kategori as $tmp) {
    if($tmp->kategori_kunjungan == 'BUMN'){
     $c5=$tmp->jumlah_kat;
     $flag = 0;
    }
  }
  if($flag) $c5=0;
  ?>

  <?php
  $flag=1;
  foreach ($kategori as $tmp) {
    if($tmp->kategori_kunjungan == 'Arsip Perseorangan'){
     $c6=$tmp->jumlah_kat;
     $flag = 0;
    }
  }
  if($flag) $c6=0;
  ?>

  <?php
  $flag=1;
  foreach ($kategori as $tmp) {
    if($tmp->kategori_kunjungan == 'Lain-lain'){
     $c7=$tmp->jumlah_kat;
     $flag = 0;
    }
  }
  if($flag) $c7=0;
  ?>


<!-- perhitungan media kunjungan -->
<?php
  $flag=1;
  foreach ($media as $tmp) {
    if($tmp->media_kunjungan == 'Kertas'){
     $d1=$tmp->jumlah_km;
     $flag = 0;
    }
  }
  if($flag) $d1=0;
  ?>

  <?php
  $flag=1;
  foreach ($media as $tmp) {
    if($tmp->media_kunjungan == 'Foto'){
     $d2=$tmp->jumlah_km;
     $flag = 0;
    }
  }
  if($flag) $d2=0;
  ?>

  <?php
  $flag=1;
  foreach ($media as $tmp) {
    if($tmp->media_kunjungan == 'Film'){
     $d3=$tmp->jumlah_km;
     $flag = 0;
    }
  }
  if($flag) $d3=0;
  ?>

  <?php
  $flag=1;
  foreach ($media as $tmp) {
    if($tmp->media_kunjungan == 'Kaset'){
     $d4=$tmp->jumlah_km;
     $flag = 0;
    }
  }
  if($flag) $d4=0;
  ?>

  <?php
  $flag=1;
  foreach ($media as $tmp) {
    if($tmp->media_kunjungan == 'Peta'){
     $d5=$tmp->jumlah_km;
     $flag = 0;
    }
  }
  if($flag) $d5=0;
  ?>

  <?php
  $flag=1;
  foreach ($media as $tmp) {
    if($tmp->media_kunjungan == 'Media Lain'){
     $d6=$tmp->jumlah_km;
     $flag = 0;
    }
  }
  if($flag) $d6=0;
  ?>

<!-- perhitungan jumlah kunjungan -->
<?php
  $flag=1;
  foreach ($jumlah as $tmp) {
    if($tmp->jumlah_kunjungan == 'Pertama kali'){
     $e1=$tmp->jumlah_kj;
     $flag = 0;
    }
  }
  if($flag) $e1=0;
  ?>

<?php
  $flag=1;
  foreach ($jumlah as $tmp) {
    if($tmp->jumlah_kunjungan == '2 kali'){
     $e2=$tmp->jumlah_kj;
     $flag = 0;
    }
  }
  if($flag) $e2=0;
  ?>

<?php
  $flag=1;
  foreach ($jumlah as $tmp) {
    if($tmp->jumlah_kunjungan == '3 kali'){
     $e3=$tmp->jumlah_kj;
     $flag = 0;
    }
  }
  if($flag) $e3=0;
  ?>

<?php
  $flag=1;
  foreach ($jumlah as $tmp) {
    if($tmp->jumlah_kunjungan == '4 kali'){
     $e4=$tmp->jumlah_kj;
     $flag = 0;
    }
  }
  if($flag) $e4=0;
  ?>

<?php
  $flag=1;
  foreach ($jumlah as $tmp) {
    if($tmp->jumlah_kunjungan == '? 5 kali'){
     $e5=$tmp->jumlah_kj;
     $flag = 0;
    }
  }
  if($flag) $e5=0;
  ?>

<!-- perhitungan proyeksi kunjungan -->
<?php
  $flag=1;
  foreach ($proyeksi as $tmp) {
    if($tmp->proyeksi_kunjungan == '1 - 2 hari'){
     $f1=$tmp->jumlah_kp;
     $flag = 0;
    }
  }
  if($flag) $f1=0;
  ?>

<?php
  $flag=1;
  foreach ($proyeksi as $tmp) {
    if($tmp->proyeksi_kunjungan == '3 - 4 hari'){
     $f2=$tmp->jumlah_kp;
     $flag = 0;
    }
  }
  if($flag) $f2=0;
  ?>

<?php
  $flag=1;
  foreach ($proyeksi as $tmp) {
    if($tmp->proyeksi_kunjungan == '5 - 6 hari'){
     $f3=$tmp->jumlah_kp;
     $flag = 0;
    }
  }
  if($flag) $f3=0;
  ?>

<?php
  $flag=1;
  foreach ($proyeksi as $tmp) {
    if($tmp->proyeksi_kunjungan == '? 7 hari'){
     $f4=$tmp->jumlah_kp;
     $flag = 0;
    }
  }
  if($flag) $f4=0;
  ?>

  <?php $jumlah=$b1+$b2+$b3+$b4+$b5;?>


  <div class="container">
  <h2 style="font-family: anton; text-align:center">Grafik Pengunjung</h2>
  <h3 style="font-family:anton; text-align:center"><?php $bulan=$this->session->userdata('bulan');echo $bulan?><?php $tahun=$this->session->userdata('tahun'); echo $tahun;?> &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; <?php echo $jumlah;?> Pengunjung</h3>

   
    <div class="container" style="background-color: white; padding-top:5%; padding-bottom:5%;"> 

    <!-- <div class="tabbed_area"> -->
       <table>
          <tr>
            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK-->
            <div id="grafik-keperluan"></div>
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
            google.charts.load('current', {'packages':['corechart']});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
              var data = google.visualization.arrayToDataTable([
              ['Keperluan', 'Jumlah'],
              ['Skripsi/Tesis/Disertasi', <?php echo $a1 ?>],
              ['Tugas Kuliah', <?php echo $a2 ?>],
              ['Pembuktian Hukum', <?php echo $a3 ?>],
              ['Penulisan Sejarah', <?php echo $a4 ?>],
              ['Penelusuran Silsilah Keluarga', <?php echo $a5 ?>],
              ['Kedinasan', <?php echo $a6 ?>],
              ['Lain-lain', <?php echo $a7 ?>]
            ]);

              var options = {'title':'Keperluan', 'width':550, 'height':400};
              var chart = new google.visualization.PieChart(document.getElementById('grafik-keperluan'));
              chart.draw(data, options);
            }
            </script>
            <!-- AKHIR DARI GRAFIK -->
            </th>

            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK-->
            <div id="grafik-fokus"></div>
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
            google.charts.load('current', {'packages':['corechart']});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
              var data = google.visualization.arrayToDataTable([
              ['Fokus Penelitian', 'Jumlah'],
              ['Arsip sebelum 1900', <?php echo $b1 ?>],
              ['1901-1945', <?php echo $b2 ?>],
              ['1946-1965', <?php echo $b3 ?>],
              ['1966-1985', <?php echo $b4 ?>],
              ['1986-sekarang', <?php echo $b5 ?>]
            ]);

              var options = {'title':'Fokus Penelitian', 'width':550, 'height':400};
              var chart = new google.visualization.PieChart(document.getElementById('grafik-fokus'));
              chart.draw(data, options);
            }
            </script>
            <!-- AKHIR DARI GRAFIK -->
            </th>
          </tr>

          <tr>
            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK-->
            <div id="grafik-kategori"></div>
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
            google.charts.load('current', {'packages':['corechart']});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
              var data = google.visualization.arrayToDataTable([
              ['Kategori', 'Jumlah'],
              ['Umum', <?php echo $c1 ?>],
              ['Secretary Oost Java', <?php echo $c2 ?>],
              ['Lembaga Vertikal', <?php echo $c3 ?>],
              ['Organisasi Perangkat Daerah', <?php echo $c4 ?>],
              ['BUMN', <?php echo $c5 ?>],
              ['Arsip Perseorangan', <?php echo $c6 ?>],
              ['Lain-lain', <?php echo $c7 ?>]
            ]);

              var options = {'title':'Kategori Arsip', 'width':550, 'height':400};
              var chart = new google.visualization.PieChart(document.getElementById('grafik-kategori'));
              chart.draw(data, options);
            }
            </script>
            <!-- AKHIR DARI GRAFIK -->
            </th>

            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK-->
            <div id="grafik-media"></div>
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
            google.charts.load('current', {'packages':['corechart']});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
              var data = google.visualization.arrayToDataTable([
              ['Media', 'Jumlah'],
              ['Kertas', <?php echo $d1 ?>],
              ['Foto', <?php echo $d2 ?>],
              ['Film', <?php echo $d3 ?>],
              ['Kaset', <?php echo $d4 ?>],
              ['Peta', <?php echo $d5 ?>],
              ['Lain-lain', <?php echo $d6 ?>]
            ]);

              var options = {'title':'Media Arsip', 'width':550, 'height':400};
              var chart = new google.visualization.PieChart(document.getElementById('grafik-media'));
              chart.draw(data, options);
            }
            </script>
            <!-- AKHIR DARI GRAFIK -->
            </th>
          </tr>

          <tr>
            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK-->
            <div id="grafik-jumlahkunjungan"></div>
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
            google.charts.load('current', {'packages':['corechart']});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
              var data = google.visualization.arrayToDataTable([
              ['Jumlah Kunjungan', 'Jumlah'],
              ['Ke-1', <?php echo $e1 ?>],
              ['Ke-2', <?php echo $e2 ?>],
              ['Ke-3', <?php echo $e3 ?>],
              ['Ke-4', <?php echo $e4 ?>],
              ['> 5', <?php echo $e5 ?>]
            ]);

              var options = {'title':'Jumlah Kunjungan', 'width':550, 'height':400};
              var chart = new google.visualization.PieChart(document.getElementById('grafik-jumlahkunjungan'));
              chart.draw(data, options);
            }
            </script>
            <!-- AKHIR DARI GRAFIK -->
            </th>

            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK-->
            <div id="grafik-proyeksi"></div>
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
            google.charts.load('current', {'packages':['corechart']});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
              var data = google.visualization.arrayToDataTable([
              ['Proyeksi', 'Jumlah'],
              ['1-2 hari', <?php echo $f1 ?>],
              ['3-4 hari', <?php echo $f2 ?>],
              ['5-6 hari', <?php echo $f3 ?>]
            ]);

              var options = {'title':'Proyeksi Waktu Penelitian', 'width':550, 'height':400};
              var chart = new google.visualization.PieChart(document.getElementById('grafik-proyeksi'));
              chart.draw(data, options);
            }
            </script>
            <!-- AKHIR DARI GRAFIK -->
            </th>
          </tr>
        </table>
    <!-- </div> tabbed area -->
    </div> <!-- container -->
  </div> <!-- container -->



<script type="text/javascript">
  google.charts.load('visualization', '1.0', {'packages':['corechart']});
  google.charts.setOnLoadCallback(drawChart);

  function drawChart() {

    var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Work',     11],
          ['Eat',      2],
          ['Commute',  2],
          ['Watch TV', 2],
          ['Sleep',    7]
        ]);

  var options = {
          title: 'My Daily Activities',
      backgroundColor: '#ddd',
      chartArea: {width:500,height:200}
        };

    $(".tabs a[title='content_2']").click()
    $(".tabs a[title='content_1']").click()

    var chart = new      google.visualization.PieChart(document.getElementById('chart'));

         
    chart.draw(data, options);

 var chart1= new      google.visualization.PieChart(document.getElementById('chart1'));

         
    chart1.draw(data, options);
  }





// When the document loads do everything inside here ...
    $(document).ready(function(){
    
    // When a link is clicked
    $("a.tab").click(function () {
      
      
      // switch all tabs off
      $(".active").removeClass("active");
      
      // switch this tab on
      $(this).addClass("active");
      
      // slide all content up
      $(".content").slideUp();
      
      // slide this content up
      var content_show = $(this).attr("title");
      $("#"+content_show).slideDown();
      
    });
  
    });

    function myFunction() {
    window.print();
    }

    window.onload = function() {
      myFunction();
    };

</script>


</body>
</html>