<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Layanan Kearsipan</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/menu-style.css">
  <link href='https://fonts.googleapis.com/css?family=Anton' rel='stylesheet'>
  <link href='https://fonts.googleapis.com/css?family=Fjalla+One' rel='stylesheet'>
</head>

<body style="background-color:#f2f2f2">
	<div class="container text-center" style="margin-top:8%">
		<span class="glyphicon glyphicon-check" style="font-size:800%; color:#008CCC; text-align:center;"></span>
		<h1 style="font-size : 500%; font-family: anton;">Terima kasih atas kunjungan Anda</h1>
		<h1 style="font-size : 220%; font-family: anton;">Kuesioner Anda akan diproses</h1><br>
		<a href="<?php echo base_url('layanan/index2');?>"><button class="button button1" onclick="document.getElementById('id02').style.display='block'" style="width: 30%" >Kembali ke Menu</button></a>
	</div>
</body>
</html>