<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Layanan Kearsipan</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/menu-style.css">
  <link href='https://fonts.googleapis.com/css?family=Anton' rel='stylesheet'>
  <link href='https://fonts.googleapis.com/css?family=Fjalla+One' rel='stylesheet'>
</head>

<body style="background-color:#f2f2f2">
<nav class="navbar navbar-default"; style="background-color: #008CCC;">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" style="font-family: fjalla one; color: white" href="<?php echo base_url('Layanan/index2');?>">Disperpusip</a>
    </div>
  </div>
</nav>

<div class="container">
  <h2 style="font-family: anton; text-align:center">Kuisioner</h2>  
  <h3 style="font-family: anton; text-align:center">Isilah kuisioner berikut ini berdasarkan tingkat keyakinan <br>(STS)=Sangat Tidak Setuju (TS)=Tidak Setuju (R)=Ragu-ragu (S)=Setuju (SS)=Sangat Setuju</h3><br>

<div class="container" style="background-color: white; padding-left: 10%; padding-top:5%">
<h4 style="font-weight: 900">Bagian 3 : Waktu Layanan<h4>  
  <form method="POST" class="form-horizontal" action="<?php echo base_url('Layanan/kuesioner3')?>">
  <div class="form-group">
        <h4>1.  Memiliki jadwal pelayanan arsip</h4>
        <div class="row">
          <div class="col-sm-2">
            <input type="radio" name="question-1-answers" value="STS" />
            <label> STS </label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-1-answers" value="TS" />
            <label> TS</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-1-answers" value="R" />
            <label> R</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-1-answers" value="S" />
            <label> S</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-1-answers" value="SS" required/>
            <label> SS</label></div>
        </div>
  </div>
  <div class="form-group">
        <h4>2.  Jadwal layanan mudah dilihat pengguna</h4>
        <div class="row">
          <div class="col-sm-2">
            <input type="radio" name="question-2-answers" value="STS" />
            <label> STS </label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-2-answers" value="TS" />
            <label> TS</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-2-answers" value="R" />
            <label> R</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-2-answers" value="S" />
            <label> S</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-2-answers" value="SS" required/>
            <label> SS</label></div>
        </div>
  </div>
  <div class="form-group">
        <h4>3.  Ada kesesuaian jadwal dengan praktik layanan</h4>
        <div class="row">
          <div class="col-sm-2">
            <input type="radio" name="question-3-answers" value="STS" />
            <label> STS </label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-3-answers" value="TS" />
            <label> TS</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-3-answers" value="R" />
            <label> R</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-3-answers" value="S" />
            <label> S</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-3-answers" value="SS" required/>
            <label> SS</label></div>
        </div>
  </div>
  <div class="form-group">
        <h4>4.  Petugas cepat dalam memberikan layanan penelusuran sumber arsip</h4>
        <div class="row">
          <div class="col-sm-2">
            <input type="radio" name="question-4-answers" value="STS" />
            <label> STS </label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-4-answers" value="TS" />
            <label> TS</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-4-answers" value="R" />
            <label> R</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-4-answers" value="S" />
            <label> S</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-4-answers" value="SS" required/>
            <label> SS</label></div>
        </div>
  </div>
  <div class="form-group">
        <h4>5.  Petugas cepat dalam melayani peminjaman arsip</h4>
        <div class="row">
          <div class="col-sm-2">
            <input type="radio" name="question-5-answers" value="STS" />
            <label> STS </label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-5-answers" value="TS" />
            <label> TS</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-5-answers" value="R" />
            <label> R</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-5-answers" value="S" />
            <label> S</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-5-answers" value="SS" required/>
            <label> SS</label></div>
        </div>
  </div>
   <div class="form-group">
        <h4>6.  Petugas cepat dalam melayani penggandaan/reproduksi arsip</h4>
        <div class="row">
          <div class="col-sm-2">
            <input type="radio" name="question-6-answers" value="STS" />
            <label> STS </label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-6-answers" value="TS" />
            <label> TS</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-6-answers" value="R" />
            <label> R</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-6-answers" value="S" />
            <label> S</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-6-answers" value="SS" required/>
            <label> SS</label></div>
        </div>
  </div>
   <div class="form-group">
        <h4>7.  Waktu layanan penelusuran sesuai harapan pengguna</h4>
        <div class="row">
          <div class="col-sm-2">
            <input type="radio" name="question-7-answers" value="STS" />
            <label> STS </label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-7-answers" value="TS" />
            <label> TS</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-7-answers" value="R" />
            <label> R</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-7-answers" value="S" />
            <label> S</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-7-answers" value="SS" required/>
            <label> SS</label></div>
        </div>
  </div>
   <div class="form-group">
        <h4>8.  Waktu layanan peminjaman sesuai harapan pengguna</h4>
        <div class="row">
          <div class="col-sm-2">
            <input type="radio" name="question-8-answers" value="STS" />
            <label> STS </label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-8-answers" value="TS" />
            <label> TS</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-8-answers" value="R" />
            <label> R</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-8-answers" value="S" />
            <label> S</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-8-answers" value="SS" required/>
            <label> SS</label></div>
        </div>
  </div>
   <div class="form-group">
        <h4>9.  Waktu layanan penggandaan/reproduksi sesuai harapan pengguna</h4>
        <div class="row">
          <div class="col-sm-2">
            <input type="radio" name="question-9-answers" value="STS" />
            <label> STS </label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-9-answers" value="TS" />
            <label> TS</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-9-answers" value="R" />
            <label> R</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-9-answers" value="S" />
            <label> S</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-9-answers" value="SS" required/>
            <label> SS</label></div>
        </div>
  </div>
    <div class="row">
      <div class="col-sm-8"><input type="hidden" class="form-control" id="no_id"  name="no_id" value="<?php echo $this->session->userdata('id');?>"></div>
      <div class="col-sm-3">
        <button type="submit" >Selanjutnya</button>
      </div>
    </div>
</div>

</body>
</html>