<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Layanan Kearsipan</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/grafik.css">
  <link href='https://fonts.googleapis.com/css?family=Anton' rel='stylesheet'>
  <link href='https://fonts.googleapis.com/css?family=Fjalla+One' rel='stylesheet'>
</head>

<body>
<?php
  $flag=1;
  foreach ($usia as $tmp) {
    if($tmp->umur_anggota == '? 15'){
     $v1=$tmp->jumlah_usia;
     $flag = 0;
    }
  }
  if($flag) $v1=0;
  ?>

  <?php
  $flag=1;
  foreach ($usia as $tmp) {
    if($tmp->umur_anggota == '16 - 20'){
     $v2= $tmp->jumlah_usia;
     $flag = 0;
    }
  }
  if($flag) $v2=0;
  ?>
  
  <?php
  $flag=1;
  foreach ($usia as $tmp) {
    if($tmp->umur_anggota == '21 - 25'){
     $v3= $tmp->jumlah_usia;
     
     $flag = 0;
    }
  }
  if($flag) $v3=0;
  ?>

  <?php
  $flag=1;
  foreach ($usia as $tmp) {
    if($tmp->umur_anggota == '26 - 30'){
     $v4= $tmp->jumlah_usia;
     $flag = 0;
    }
  }
  if($flag) $v4=0;
  ?>

  <?php
  $flag=1;
  foreach ($usia as $tmp) {
    if($tmp->umur_anggota == '31 - 35'){
     $v5= $tmp->jumlah_usia;
     $flag = 0;
    }
  }
  if($flag) $v5=0;
  ?>

  <?php
  $flag=1;
  foreach ($usia as $tmp) {
    if($tmp->umur_anggota == '36 - 40'){
     $v6= $tmp->jumlah_usia;
     $flag = 0;
    }
  }
  if($flag) $v6=0;
  ?>
  
  <?php
  $flag=1;
  foreach ($usia as $tmp) {
    if($tmp->umur_anggota == '41 - 45'){
     $v7= $tmp->jumlah_usia;
     $flag = 0;
    }
  }
  if($flag) $v7=0;
  ?>

  <?php
  $flag=1;
  foreach ($usia as $tmp) {
    if($tmp->umur_anggota == '46 - 50'){
     $v8= $tmp->jumlah_usia;
     $flag = 0;
    }
  }
  if($flag) $v8=0;
  ?>

  <?php
  $flag=1;
  foreach ($usia as $tmp) {
    if($tmp->umur_anggota == '51 - 55'){
     $v9= $tmp->jumlah_usia;
     $flag = 0;
    }
  }
  if($flag) $v9=0;
  ?>

  <?php
  $flag=1;
  foreach ($usia as $tmp) {
    if($tmp->umur_anggota == '56 - 60'){
     $v10= $tmp->jumlah_usia;
     $flag = 0;
    }
  }
  if($flag) $v10=0;
  ?>

  <?php
  $flag=1;
  foreach ($usia as $tmp) {
    if($tmp->umur_anggota == '? 61'){
     $v11= $tmp->jumlah_usia;
     $flag = 0;
    }
  }
  if($flag) $v11=0;
  ?>
  
<!-- perhitungan jenis Kelamin -->
  <?php
  $flag=1;
  foreach ($jk as $tmp) {
    if($tmp->jk_anggota == 'L'){
     $j1=$tmp->jumlah_jk;
     $flag = 0;
    }
  }
  if($flag) $j1=0;
  ?>

  <?php
  $flag=1;
  foreach ($jk as $tmp) {
    if($tmp->jk_anggota == 'P'){
     $j2=$tmp->jumlah_jk;
     $flag = 0;
    }
  }
  if($flag) $j2=0;
  ?>

  <!-- perhitungan Kewarganegaraan -->
  <?php
  $flag=1;
  foreach ($kwn as $tmp) {
    if($tmp->kewarganegaraan_anggota == 'WNI'){
     $w1=$tmp->jumlah_kwn;
     $flag = 0;
    }
  }
  if($flag) $w1=0;
  ?>

  <?php
  $flag=1;
  foreach ($kwn as $tmp) {
    if($tmp->kewarganegaraan_anggota == 'WNA'){
     $w2=$tmp->jumlah_kwn;
     $flag = 0;
    }
  }
  if($flag) $w2=0;
  ?>
  <!-- perhitungan pendidikan terakhir -->
  <?php
  $flag=1;
  foreach ($pt as $tmp) {
    if($tmp->pendidikan_pengguna == 'SMA'){
     $p1=$tmp->jumlah_pt;
     $flag = 0;
    }
  }
  if($flag) $p1=0;
  ?>

  <?php
  $flag=1;
  foreach ($pt as $tmp) {
    if($tmp->pendidikan_pengguna == 'Diploma I - III'){
     $p2=$tmp->jumlah_pt;
     $flag = 0;
    }
  }
  if($flag) $p2=0;
  ?>

  <?php
  $flag=1;
  foreach ($pt as $tmp) {
    if($tmp->pendidikan_pengguna == 'Sarjana / Diploma IV'){
     $p3=$tmp->jumlah_pt;
     $flag = 0;
    }
  }
  if($flag) $p3=0;
  ?>

  <?php
  $flag=1;
  foreach ($pt as $tmp) {
    if($tmp->pendidikan_pengguna == 'Pasca Sarjana'){
     $p4=$tmp->jumlah_pt;
     $flag = 0;
    }
  }
  if($flag) $p4=0;
  ?>

  <?php
  $flag=1;
  foreach ($pt as $tmp) {
    if($tmp->pendidikan_pengguna == 'Doktoral'){
     $p5=$tmp->jumlah_pt;
     $flag = 0;
    }
  }
  if($flag) $p5=0;
  ?>
  <!-- perhitungan profesi -->
  <?php
  $flag=1;
  foreach ($prof as $tmp) {
    if($tmp->profesi_pengguna == 'Pelajar/Mahasiswa'){
     $pr1=$tmp->jumlah_prof;
     $flag = 0;
    }
  }
  if($flag) $pr1=0;
  ?>

  <?php
  $flag=1;
  foreach ($prof as $tmp) {
    if($tmp->profesi_pengguna == 'Dosen'){
     $pr2=$tmp->jumlah_prof;
     $flag = 0;
    }
  }
  if($flag) $pr2=0;
  ?>

  <?php
  $flag=1;
  foreach ($prof as $tmp) {
    if($tmp->profesi_pengguna == 'Peneliti/Sejarawan'){
     $pr3=$tmp->jumlah_prof;
     $flag = 0;
    }
  }
  if($flag) $pr3=0;
  ?>

  <?php
  $flag=1;
  foreach ($prof as $tmp) {
    if($tmp->profesi_pengguna == 'Perusahaan/Swasta'){
     $pr4=$tmp->jumlah_prof;
     $flag = 0;
    }
  }
  if($flag) $pr4=0;
  ?>

  <?php
  $flag=1;
  foreach ($prof as $tmp) {
    if($tmp->profesi_pengguna == 'Instansi Pemerintah Provinsi'){
     $pr5=$tmp->jumlah_prof;
     $flag = 0;
    }
  }
  if($flag) $pr5=0;
  ?>

  <?php
  $flag=1;
  foreach ($prof as $tmp) {
    if($tmp->profesi_pengguna == 'Instansi Kabupaten/Kota'){
     $pr6=$tmp->jumlah_prof;
     $flag = 0;
    }
  }
  if($flag) $pr6=0;
  ?>

  <?php
  $flag=1;
  foreach ($prof as $tmp) {
    if($tmp->profesi_pengguna == 'Lain-lain'){
     $pr7=$tmp->jumlah_prof;
     $flag = 0;
    }
  }
  if($flag) $pr7=0;
  ?>
  <!-- perhitungan tempat studi -->
  <?php
  $flag=1;
  foreach ($tmpstudi as $tmp) {
    if($tmp->tempat_studi == 'Institut Teknologi Sepuluh Nopember'){
     $ts1=$tmp->jumlah_ts;
     $flag = 0;
    }
  }
  if($flag) $ts1=0;
  ?>

  <?php
  $flag=1;
  foreach ($tmpstudi as $tmp) {
    if($tmp->tempat_studi == 'Institut Teknologi Sepuluh Nopember'){
     $ts2=$tmp->jumlah_ts;
     $flag = 0;
    }
  }
  if($flag) $ts2=0;
  ?>

  <?php
  $flag=1;
  foreach ($tmpstudi as $tmp) {
    if($tmp->tempat_studi == 'Universitas Brawijaya'){
     $ts3=$tmp->jumlah_ts;
     $flag = 0;
    }
  }
  if($flag) $ts3=0;
  ?>

  <?php
  $flag=1;
  foreach ($tmpstudi as $tmp) {
    if($tmp->tempat_studi == 'Universitas Negeri Surabaya'){
     $ts4=$tmp->jumlah_ts;
     $flag = 0;
    }
  }
  if($flag) $ts4=0;
  ?>

  <?php
  $flag=1;
  foreach ($tmpstudi as $tmp) {
    if($tmp->tempat_studi == 'Universitas Negeri Jember'){
     $ts5=$tmp->jumlah_ts;
     $flag = 0;
    }
  }
  if($flag) $ts5=0;
  ?>

  <?php
  $flag=1;
  foreach ($tmpstudi as $tmp) {
    if($tmp->tempat_studi == 'Universitas Negeri Malang'){
     $ts6=$tmp->jumlah_ts;
     $flag = 0;
    }
  }
  if($flag) $ts6=0;
  ?>

  <?php
  $flag=1;
  foreach ($tmpstudi as $tmp) {
    if($tmp->tempat_studi == 'Universitas Islam Negeri Sunan Ampel'){
     $ts7=$tmp->jumlah_ts;
     $flag = 0;
    }
  }
  if($flag) $ts7=0;
  ?>

  <?php
  $flag=1;
  foreach ($tmpstudi as $tmp) {
    if($tmp->tempat_studi == 'Universitas Pembangunan Nasional'){
     $ts8=$tmp->jumlah_ts;
     $flag = 0;
    }
  }
  if($flag) $ts8=0;
  ?>

  <?php
  $flag=1;
  foreach ($tmpstudi as $tmp) {
    if($tmp->tempat_studi == 'Universitas Muhammadiyah Malang'){
     $ts9=$tmp->jumlah_ts;
     $flag = 0;
    }
  }
  if($flag) $ts9=0;
  ?>

  <?php
  $flag=1;
  foreach ($tmpstudi as $tmp) {
    if($tmp->tempat_studi == 'Universitas Muhammadiyah Surabaya'){
     $ts10=$tmp->jumlah_ts;
     $flag = 0;
    }
  }
  if($flag) $ts10=0;
  ?>

  <?php
  $flag=1;
  foreach ($tmpstudi as $tmp) {
    if($tmp->tempat_studi == 'Universitas Muhammadiyah Sidoarjo'){
     $ts11=$tmp->jumlah_ts;
     $flag = 0;
    }
  }
  if($flag) $ts11=0;
  ?>

  <?php
  $flag=1;
  foreach ($tmpstudi as $tmp) {
    if($tmp->tempat_studi == 'Lain-lain'){
     $ts12=$tmp->jumlah_ts;
     $flag = 0;
    }
  }
  if($flag) $ts12=0;
  ?>

  <?php 
  $jumlah1 = $v1+$v2+$v3+$v4+$v5+$v6+$v7+$v8+$v9+$v10+$v11; //umur
  $jumlah2 = $j1+$j2; //jenis kelamin
  $jumlah3 = $w1+$w2;//kewarganegaraan
  $jumlah4 = $p1+$p2+$p3+$p4+$p5;//pendidikan terakhir
  $jumlah5 = $pr1+$pr2+$pr3+$pr4+$pr5+$pr6+$pr7;//profesi
  $jumlah6 = $ts1+$ts2+$ts3+$ts4+$ts5+$ts6+$ts7+$ts8+$ts9+$ts10+$ts11;
?>

  <div class="container">
  <h2 style="font-family: anton; text-align:center">Grafik Pengguna</h2>
  <h3 style="font-family: anton; text-align:center">Agustus 2017 &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; 100 Pengguna</h3>  
    <div class="container" style="background-color: white; padding-top:5%; padding-bottom:5%;"> 

    <!-- <div class="tabbed_area"> -->
       <table>
          <tr>
            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK-->
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
              google.charts.load("current", {packages:['corechart']});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ["Element", "Density", { role: "style" } ],
                  ['Usia < 15', <?php echo $v1 ?>, "red"], 
                  ['Usia 15-20', <?php echo $v2 ?>, "blue"],
                  ['Usia 21-25', <?php echo $v3 ?>, "green"],
                  ['Usia 26-30', <?php echo $v4 ?>, ",yellow"],
                  ['Usia 31-35', <?php echo $v5 ?>, "pink"],
                  ['Usia 36-40', <?php echo $v6 ?>, "purple"],
                  ['Usia 41-45', <?php echo $v7 ?>, "orange"],
                  ['Usia 46-50', <?php echo $v8 ?>, "cyan"],
                  ['Usia 51-55', <?php echo $v9 ?>,"coral"],
                  ['Usia 56-60', <?php echo $v10 ?>, "Brown"],
                  ['Usia > 60', <?php echo $v11 ?>, "Gold"]
                ]);

                var view = new google.visualization.DataView(data);
                view.setColumns([0, 1,
                                 { calc: "stringify",
                                   sourceColumn: 1,
                                   type: "string",
                                   role: "annotation" },
                                 2]);

                var options = {
                  title: "Usia",
                  width: 550,
                  height: 400,
                  bar: {groupWidth: "95%"},
                  legend: { position: "none" },
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("grafik_usia1"));
                chart.draw(view, options);
            }
            </script>
            <div id="grafik_usia1"></div>
            <!-- AKHIR DARI GRAFIK -->          
            </th>

            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK-->
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
              google.charts.load("current", {packages:['corechart']});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ["Element", "Density", { role: "style" } ],
                 ['Laki-laki', <?php echo $j1 ?>, "red"], 
                  ['Perempuan', <?php echo $j2 ?>, "blue"]
                ]);

                var view = new google.visualization.DataView(data);
                view.setColumns([0, 1,
                                 { calc: "stringify",
                                   sourceColumn: 1,
                                   type: "string",
                                   role: "annotation" },
                                 2]);

                var options = {
                  title: "Jenis Kelamin",
                  width: 550,
                  height: 400,
                  bar: {groupWidth: "95%"},
                  legend: { position: "none" },
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("grafik_jk1"));
                chart.draw(view, options);
            }
            </script>
            <div id="grafik_jk1"></div>
            <!-- AKHIR DARI GRAFIK -->
            </th>
          </tr>

          <tr>
            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK-->
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
              google.charts.load("current", {packages:['corechart']});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ["Element", "Density", { role: "style" } ],
                  ['WNA', <?php echo $w1 ?>, "red"], 
                  ['WNI', <?php echo $w2 ?>, "blue"]
                ]);

                var view = new google.visualization.DataView(data);
                view.setColumns([0, 1,
                                 { calc: "stringify",
                                   sourceColumn: 1,
                                   type: "string",
                                   role: "annotation" },
                                 2]);

                var options = {
                  title: "Kewarganegaraan",
                  width: 550,
                  height: 400,
                  bar: {groupWidth: "95%"},
                  legend: { position: "none" },
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("grafik_kewarganegaraan1"));
                chart.draw(view, options);
            }
            </script>
            <div id="grafik_kewarganegaraan1"></div>
            <!-- AKHIR DARI GRAFIK -->
            </th>

            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK-->
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
              google.charts.load("current", {packages:['corechart']});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ["Element", "Density", { role: "style" } ],
                  ['SMA', <?php echo $p1 ?>, "red"],
                  ['Diploma I-III', <?php echo $p2 ?>, "blue"],
                  ['Sarjana/Diploma IV', <?php echo $p3 ?>, "green"],
                  ['Pasca Sarjana', <?php echo $p4 ?>, "yellow"],
                  ['Doktoral', <?php echo $p5 ?>, "pink"]
                ]);

                var view = new google.visualization.DataView(data);
                view.setColumns([0, 1,
                                 { calc: "stringify",
                                   sourceColumn: 1,
                                   type: "string",
                                   role: "annotation" },
                                 2]);

                var options = {
                  title: "Pendidikan Terakhir",
                  width: 550,
                  height: 400,
                  bar: {groupWidth: "95%"},
                  legend: { position: "none" },
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("grafik_pendidikan1"));
                chart.draw(view, options);
            }
            </script>
            <div id="grafik_pendidikan1"></div>
            <!-- AKHIR DARI GRAFIK -->
            </th>
          </tr>

          <tr>
            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK-->
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
              google.charts.load("current", {packages:['corechart']});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ["Element", "Density", { role: "style" } ],
                  ['Pelajar/Mahasiswa', <?php echo $pr1 ?>, "red"],
                  ['Dosen', <?php echo $pr2 ?>, "blue"],
                  ['Peneliti/Sejarawan', <?php echo $pr3 ?>, "green"],
                  ['Perusahaan/Swasta', <?php echo $pr4 ?>, "yellow"],
                  ['Pemprov', <?php echo $pr5 ?>, "pink"],
                  ['Pemkab', <?php echo $pr6 ?>, "purple"],
                  ['Lain-lain', <?php echo $pr7 ?>, "orange"]
                ]);

                var view = new google.visualization.DataView(data);
                view.setColumns([0, 1,
                                 { calc: "stringify",
                                   sourceColumn: 1,
                                   type: "string",
                                   role: "annotation" },
                                 2]);

                var options = {
                  title: "Profesi",
                  width: 550,
                  height: 400,
                  bar: {groupWidth: "95%"},
                  legend: { position: "none" },
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("grafik_profesi1"));
                chart.draw(view, options);
            }
            </script>
            <div id="grafik_profesi1"></div>
            <!-- AKHIR DARI GRAFIK -->
            </th>

            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK-->
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
              google.charts.load("current", {packages:['corechart']});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ["Element", "Density", { role: "style" } ],
                  ['ITS', <?php echo $ts1 ?>, "red"], 
                  ['Unair', <?php echo $ts2 ?>, "blue"],
                  ['UB', <?php echo $ts3 ?>, "green"],
                  ['Unesa', <?php echo $ts4 ?>, ",yellow"],
                  ['Unej', <?php echo $ts5 ?>, "pink"],
                  ['UNM', <?php echo $ts6 ?>, "purple"],
                  ['UINSA', <?php echo $ts7 ?>, "orange"],
                  ['UPN', <?php echo $ts8 ?>, "cyan"],
                  ['UMM', <?php echo $ts9 ?>,"coral"],
                  ['UM SBY', <?php echo $ts10 ?>, "Brown"],
                  ['UM SDA', <?php echo $ts11 ?>, "Gold"],
                  ['Lain-lain', <?php echo $ts12 ?>, "Lime"]
                ]);

                var view = new google.visualization.DataView(data);
                view.setColumns([0, 1,
                                 { calc: "stringify",
                                   sourceColumn: 1,
                                   type: "string",
                                   role: "annotation" },
                                 2]);

                var options = {
                  title: "Tempat Studi",
                  width: 550,
                  height: 400,
                  bar: {groupWidth: "95%"},
                  legend: { position: "none" },
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("grafik_tempatstudi1"));
                chart.draw(view, options);
            }
            </script>
            <div id="grafik_tempatstudi1"></div>
            <!-- AKHIR DARI GRAFIK -->
            </th>
          </tr>
        </table>
    <!-- </div> tabbed area -->
    </div> <!-- container -->
  </div> <!-- container -->



<script type="text/javascript">
  google.charts.load('visualization', '1.0', {'packages':['corechart']});
  google.charts.setOnLoadCallback(drawChart);

  function drawChart() {

    var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Work',     11],
          ['Eat',      2],
          ['Commute',  2],
          ['Watch TV', 2],
          ['Sleep',    7]
        ]);

  var options = {
          title: 'My Daily Activities',
      backgroundColor: '#ddd',
      chartArea: {width:500,height:200}
        };

    $(".tabs a[title='content_2']").click()
    $(".tabs a[title='content_1']").click()

    var chart = new      google.visualization.PieChart(document.getElementById('chart'));

         
    chart.draw(data, options);

 var chart1= new      google.visualization.PieChart(document.getElementById('chart1'));

         
    chart1.draw(data, options);
  }





// When the document loads do everything inside here ...
    $(document).ready(function(){
    
    // When a link is clicked
    $("a.tab").click(function () {
      
      
      // switch all tabs off
      $(".active").removeClass("active");
      
      // switch this tab on
      $(this).addClass("active");
      
      // slide all content up
      $(".content").slideUp();
      
      // slide this content up
      var content_show = $(this).attr("title");
      $("#"+content_show).slideDown();
      
    });
  
    });

    function myFunction() {
    window.print();
    }

    window.onload = function() {
      myFunction();
    };

</script>


</body>
</html>