<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Layanan Kearsipan</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/grafik.css">
  <link href='https://fonts.googleapis.com/css?family=Anton' rel='stylesheet'>
  <link href='https://fonts.googleapis.com/css?family=Fjalla+One' rel='stylesheet'>
</head>

<body>

<?php
  $flag=1;
  foreach ($k1 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $a1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $a1=0;
  ?>

  <?php
  $flag=1;
  foreach ($k1 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $a2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $a2=0;
  ?>

  <?php
  $flag=1;
  foreach ($k1 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $a3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $a3=0;
  ?>

  <?php
  $flag=1;
  foreach ($k1 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $a4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $a4=0;
  ?>

  <?php
  $flag=1;
  foreach ($k1 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $a5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $a5=0;
  ?>

  <?php
  $flag=1;
  foreach ($k2 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $b1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $b1=0;
  ?>

  <?php
  $flag=1;
  foreach ($k2 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $b2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $b2=0;
  ?>

  <?php
  $flag=1;
  foreach ($k2 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $b3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $b3=0;
  ?>

  <?php
  $flag=1;
  foreach ($k2 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $b4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $b4=0;
  ?>

  <?php
  $flag=1;
  foreach ($k2 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $b5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $b5=0;
  ?>

  <?php
  $flag=1;
  foreach ($k3 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $c1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $c1=0;
  ?>

  <?php
  $flag=1;
  foreach ($k3 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $c2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $c2=0;
  ?>

  <?php
  $flag=1;
  foreach ($k3 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $c3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $c3=0;
  ?>

  <?php
  $flag=1;
  foreach ($k3 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $c4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $c4=0;
  ?>

  <?php
  $flag=1;
  foreach ($k3 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $c5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $c5=0;
  ?>

  <?php
  $flag=1;
  foreach ($k4 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $d1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $d1=0;
  ?>

   <?php
  $flag=1;
  foreach ($k4 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $d2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $d2=0;
  ?>

   <?php
  $flag=1;
  foreach ($k4 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $d3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $d3=0;
  ?>

   <?php
  $flag=1;
  foreach ($k4 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $d4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $d4=0;
  ?>

   <?php
  $flag=1;
  foreach ($k4 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $d5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $d5=0;
  ?>

   <?php
  $flag=1;
  foreach ($k5 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $e1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $e1=0;
  ?>

  <?php
  $flag=1;
  foreach ($k5 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $e2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $e2=0;
  ?>

  <?php
  $flag=1;
  foreach ($k5 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $e3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $e3=0;
  ?>

  <?php
  $flag=1;
  foreach ($k5 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $e4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $e4=0;
  ?>

  <?php
  $flag=1;
  foreach ($k5 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $e5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $e5=0;
  ?>

  <?php
  $flag=1;
  foreach ($k6 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $f1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $f1=0;
  ?>

  <?php
  $flag=1;
  foreach ($k6 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $f2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $f2=0;
  ?>

  <?php
  $flag=1;
  foreach ($k6 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $f3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $f3=0;
  ?>

  <?php
  $flag=1;
  foreach ($k6 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $f4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $f4=0;
  ?>

  <?php
  $flag=1;
  foreach ($k6 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $f5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $f5=0;
  ?>

  <?php
  $flag=1;
  foreach ($k7 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $g1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $g1=0;
  ?>

  <?php
  $flag=1;
  foreach ($k7 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $g2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $g2=0;
  ?>

  <?php
  $flag=1;
  foreach ($k7 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $g3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $g3=0;
  ?>

  <?php
  $flag=1;
  foreach ($k7 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $g4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $g4=0;
  ?>

  <?php
  $flag=1;
  foreach ($k7 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $g5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $g5=0;
  ?>

  <?php
  $flag=1;
  foreach ($k8 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $h1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $h1=0;
  ?>

  <?php
  $flag=1;
  foreach ($k8 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $h2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $h2=0;
  ?>

  <?php
  $flag=1;
  foreach ($k8 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $h3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $h3=0;
  ?>

  <?php
  $flag=1;
  foreach ($k8 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $h4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $h4=0;
  ?>

  <?php
  $flag=1;
  foreach ($k8 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $h5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $h5=0;
  ?>

  <?php
  $flag=1;
  foreach ($k9 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $i1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $i1=0;
  ?>

  <?php
  $flag=1;
  foreach ($k9 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $i2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $i2=0;
  ?>

  <?php
  $flag=1;
  foreach ($k9 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $i3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $i3=0;
  ?>

  <?php
  $flag=1;
  foreach ($k9 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $i4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $i4=0;
  ?>

  <?php
  $flag=1;
  foreach ($k9 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $i5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $i5=0;
  ?>

  <?php
  $flag=1;
  foreach ($k10 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $j1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $j1=0;
  ?>

  <?php
  $flag=1;
  foreach ($k10 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $j2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $j2=0;
  ?>

  <?php
  $flag=1;
  foreach ($k10 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $j3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $j3=0;
  ?>

  <?php
  $flag=1;
  foreach ($k10 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $j4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $j4=0;
  ?>

  <?php
  $flag=1;
  foreach ($k10 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $j5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $j5=0;
  ?>

  <?php
  $k1=$a1+$b1+$c1+$d1+$e1+$f1+$g1+$h1+$i1+$j1;
  $k2=$a2+$b2+$c2+$d2+$e2+$f2+$g2+$h2+$i2+$j2;
  $k3=$a3+$b3+$c3+$d3+$e3+$f3+$g3+$h3+$i3+$j3;
  $k4=$a4+$b4+$c4+$d4+$e4+$f4+$g4+$h4+$i4+$j4;
  $k5=$a5+$b5+$c5+$d5+$e5+$f5+$g5+$h5+$i5+$j5;
  $jumlah=($a1+$a2+$a3+$a4+$a5)/5;
  ?>


  <div class="container">
  <h2 style="font-family: anton; text-align:center">Grafik Kuesioner</h2>
  <h3 style="font-family: anton; text-align:center">Agustus 2017 &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; 300 Responden</h3>  
    <div class="container" style="background-color: white; padding-top:5%; padding-bottom:5%;"> 

    <!-- <div class="tabbed_area"> -->
       <table>
          <tr>
            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK 1111111111111111111111111111111-->
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
              google.charts.load("current", {packages:['corechart']});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ["Element", "Density", { role: "style" } ],
                  ['STS', <?php echo $a1 ?>, "red"], 
                  ['TS', <?php echo $a2 ?>, "blue"],
                  ['R', <?php echo $a3 ?>, "green"],
                  ['S', <?php echo $a4 ?>, ",yellow"],
                  ['SS', <?php echo $a5 ?>, "pink"]
                ]);

                var view = new google.visualization.DataView(data);
                view.setColumns([0, 1,
                                 { calc: "stringify",
                                   sourceColumn: 1,
                                   type: "string",
                                   role: "annotation" },
                                 2]);

                var options = {
                  title: "Kuesioner Bagian 1 : Syarat Pelayanan Arsip",
                  width: 550,
                  height: 400,
                  bar: {groupWidth: "95%"},
                  legend: { position: "none" },
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("grafik_pert1"));
                chart.draw(view, options);
            }
            </script>
            <div id="grafik_pert1"></div>
            <!-- AKHIR DARI GRAFIK -->
            </th>

            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK 2222222222222222222222222222222-->
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
              google.charts.load("current", {packages:['corechart']});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ["Element", "Density", { role: "style" } ],
                  ['STS', <?php echo $b1 ?>, "red"], 
                  ['TS', <?php echo $b2 ?>, "blue"],
                  ['R', <?php echo $b3 ?>, "green"],
                  ['S', <?php echo $b4 ?>, ",yellow"],
                  ['SS', <?php echo $b5 ?>, "pink"]
                ]);

                var view = new google.visualization.DataView(data);
                view.setColumns([0, 1,
                                 { calc: "stringify",
                                   sourceColumn: 1,
                                   type: "string",
                                   role: "annotation" },
                                 2]);

                var options = {
                  title: "Kuesioner Bagian 2 : Prosedur Layanan",
                  width: 550,
                  height: 400,
                  bar: {groupWidth: "95%"},
                  legend: { position: "none" },
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("grafik_pert12"));
                chart.draw(view, options);
            }
            </script>
            <div id="grafik_pert12"></div>
            <!-- AKHIR DARI GRAFIK -->
            </th>
          </tr>

          <tr>
            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK 333333333333333333333333333333333-->
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
              google.charts.load("current", {packages:['corechart']});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ["Element", "Density", { role: "style" } ],
                  ['STS', <?php echo $c1 ?>, "red"], 
                  ['TS', <?php echo $c2 ?>, "blue"],
                  ['R', <?php echo $c3 ?>, "green"],
                  ['S', <?php echo $c4 ?>, ",yellow"],
                  ['SS', <?php echo $c5 ?>, "pink"]
                ]);

                var view = new google.visualization.DataView(data);
                view.setColumns([0, 1,
                                 { calc: "stringify",
                                   sourceColumn: 1,
                                   type: "string",
                                   role: "annotation" },
                                 2]);

                var options = {
                  title: "Kuesioner Bagian 3 : Waktu Layanan",
                  width: 550,
                  height: 400,
                  bar: {groupWidth: "95%"},
                  legend: { position: "none" },
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("grafik_pert13"));
                chart.draw(view, options);
            }
            </script>
            <div id="grafik_pert13"></div>
            <!-- AKHIR DARI GRAFIK -->
            </th>

            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK 44444444444444444444444444444444444-->
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
              google.charts.load("current", {packages:['corechart']});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ["Element", "Density", { role: "style" } ],
                  ['STS', <?php echo $d1 ?>, "red"], 
                  ['TS', <?php echo $d2 ?>, "blue"],
                  ['R', <?php echo $d3 ?>, "green"],
                  ['S', <?php echo $d4 ?>, ",yellow"],
                  ['SS', <?php echo $d5 ?>, "pink"]
                ]);

                var view = new google.visualization.DataView(data);
                view.setColumns([0, 1,
                                 { calc: "stringify",
                                   sourceColumn: 1,
                                   type: "string",
                                   role: "annotation" },
                                 2]);

                var options = {
                  title: "Kuesioner Bagian 4 : Biaya/Tarif Layanan",
                  width: 550,
                  height: 400,
                  bar: {groupWidth: "95%"},
                  legend: { position: "none" },
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("grafik_pert14"));
                chart.draw(view, options);
            }
            </script>
            <div id="grafik_pert14"></div>
            <!-- AKHIR DARI GRAFIK -->
            </th>
          </tr>

          <tr>
            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK 555555555555555555555555555555555555555-->
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
              google.charts.load("current", {packages:['corechart']});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ["Element", "Density", { role: "style" } ],
                  ['STS', <?php echo $e1 ?>, "red"], 
                  ['TS', <?php echo $e2 ?>, "blue"],
                  ['R', <?php echo $e3 ?>, "green"],
                  ['S', <?php echo $e4 ?>, ",yellow"],
                  ['SS', <?php echo $e5 ?>, "pink"]
                ]);

                var view = new google.visualization.DataView(data);
                view.setColumns([0, 1,
                                 { calc: "stringify",
                                   sourceColumn: 1,
                                   type: "string",
                                   role: "annotation" },
                                 2]);

                var options = {
                  title: "Kuesioner Bagian 5 : Petugas Layanan",
                  width: 550,
                  height: 400,
                  bar: {groupWidth: "95%"},
                  legend: { position: "none" },
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("grafik_pert15"));
                chart.draw(view, options);
            }
            </script>
          <div id="grafik_pert15"></div>
            <!-- AKHIR DARI GRAFIK -->
            </th>

            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK 6666666666666666666666666666666666-->
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
              google.charts.load("current", {packages:['corechart']});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ["Element", "Density", { role: "style" } ],
                  ['STS', <?php echo $f1 ?>, "red"], 
                  ['TS', <?php echo $f2 ?>, "blue"],
                  ['R', <?php echo $f3 ?>, "green"],
                  ['S', <?php echo $f4 ?>, ",yellow"],
                  ['SS', <?php echo $f5 ?>, "pink"]
                ]);

                var view = new google.visualization.DataView(data);
                view.setColumns([0, 1,
                                 { calc: "stringify",
                                   sourceColumn: 1,
                                   type: "string",
                                   role: "annotation" },
                                 2]);

                var options = {
                  title: "Kuesioner Bagian 6 : Fasilitas Akses Arsip",
                  width: 550,
                  height: 400,
                  bar: {groupWidth: "95%"},
                  legend: { position: "none" },
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("grafik_pert16"));
                chart.draw(view, options);
            }
            </script>
            <div id="grafik_pert16"></div>
            <!-- AKHIR DARI GRAFIK -->
            </th>
          </tr>

          <tr>
            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK 7777777777777777777777777777777-->
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
              google.charts.load("current", {packages:['corechart']});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ["Element", "Density", { role: "style" } ],
                  ['STS', <?php echo $g1 ?>, "red"], 
                  ['TS', <?php echo $g2 ?>, "blue"],
                  ['R', <?php echo $g3 ?>, "green"],
                  ['S', <?php echo $g4 ?>, ",yellow"],
                  ['SS', <?php echo $g5 ?>, "pink"]
                ]);

                var view = new google.visualization.DataView(data);
                view.setColumns([0, 1,
                                 { calc: "stringify",
                                   sourceColumn: 1,
                                   type: "string",
                                   role: "annotation" },
                                 2]);

                var options = {
                  title: "Kuesioner Bagian 7 : Fasilitas layanan dan baca arsip",
                  width: 550,
                  height: 400,
                  bar: {groupWidth: "95%"},
                  legend: { position: "none" },
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("grafik_pert17"));
                chart.draw(view, options);
            }
            </script>
            <div id="grafik_pert17"></div>
            <!-- AKHIR DARI GRAFIK -->
            </th>

            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK 8888888888888888888888888888888-->
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
              google.charts.load("current", {packages:['corechart']});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ["Element", "Density", { role: "style" } ],
                  ['STS', <?php echo $h1 ?>, "red"], 
                  ['TS', <?php echo $h2 ?>, "blue"],
                  ['R', <?php echo $h3 ?>, "green"],
                  ['S', <?php echo $h4 ?>, ",yellow"],
                  ['SS', <?php echo $h5 ?>, "pink"]

                var view = new google.visualization.DataView(data);
                view.setColumns([0, 1,
                                 { calc: "stringify",
                                   sourceColumn: 1,
                                   type: "string",
                                   role: "annotation" },
                                 2]);

                var options = {
                  title: "Kuesioner Bagian 8 : Fasilitas Referensi Pendukung Layanan",
                  width: 550,
                  height: 400,
                  bar: {groupWidth: "95%"},
                  legend: { position: "none" },
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("grafik_pert18"));
                chart.draw(view, options);
            }
            </script>
            <div id="grafik_pert18"></div>
            <!-- AKHIR DARI GRAFIK -->
            </th>
          </tr>

          <tr>
            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK 99999999999999999999999999999999-->
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
              google.charts.load("current", {packages:['corechart']});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ["Element", "Density", { role: "style" } ],
                  ['STS', <?php echo $i1 ?>, "red"], 
                  ['TS', <?php echo $i2 ?>, "blue"],
                  ['R', <?php echo $i3 ?>, "green"],
                  ['S', <?php echo $i4 ?>, ",yellow"],
                  ['SS', <?php echo $i5 ?>, "pink"]
                ]);

                var view = new google.visualization.DataView(data);
                view.setColumns([0, 1,
                                 { calc: "stringify",
                                   sourceColumn: 1,
                                   type: "string",
                                   role: "annotation" },
                                 2]);

                var options = {
                  title: "Kuesioner Bagian 9 : Maklumat Layanan",
                  width: 550,
                  height: 400,
                  bar: {groupWidth: "95%"},
                  legend: { position: "none" },
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("grafik_pert19"));
                chart.draw(view, options);
            }
            </script>
          <div id="grafik_pert19"></div>
            <!-- AKHIR DARI GRAFIK -->
            </th>

            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK 0000000000000000000000000000-->
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
              google.charts.load("current", {packages:['corechart']});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ["Element", "Density", { role: "style" } ],
                  ['STS', <?php echo $j1 ?>, "red"], 
                  ['TS', <?php echo $j2 ?>, "blue"],
                  ['R', <?php echo $j3 ?>, "green"],
                  ['S', <?php echo $j4 ?>, ",yellow"],
                  ['SS', <?php echo $j5 ?>, "pink"]
                ]);

                var view = new google.visualization.DataView(data);
                view.setColumns([0, 1,
                                 { calc: "stringify",
                                   sourceColumn: 1,
                                   type: "string",
                                   role: "annotation" },
                                 2]);

                var options = {
                  title: "Kuesioner Bagian 10 : Penanganan Pengaduan Layanan",
                  width: 550,
                  height: 400,
                  bar: {groupWidth: "95%"},
                  legend: { position: "none" },
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("grafik_pert20"));
                chart.draw(view, options);
            }
            </script>
            <div id="grafik_pert20"></div>
            <!-- AKHIR DARI GRAFIK -->
            </th>
          </tr>

          <tr>
            <th>
            <!-- GRAFIK GRAFIK GRAFIK GRAFIK GRAFIK XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX-->
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
              google.charts.load("current", {packages:['corechart']});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ["Element", "Density", { role: "style" } ],
                  ['STS', <?php echo $k1 ?>, "red"], 
                  ['TS', <?php echo $k2 ?>, "blue"],
                  ['R', <?php echo $k3 ?>, "green"],
                  ['S', <?php echo $k4 ?>, ",yellow"],
                  ['SS', <?php echo $k5 ?>, "pink"]
                ]);

                var view = new google.visualization.DataView(data);
                view.setColumns([0, 1,
                                 { calc: "stringify",
                                   sourceColumn: 1,
                                   type: "string",
                                   role: "annotation" },
                                 2]);

                var options = {
                  title: "Rekapitulasi Total Bulan ini",
                  width: 550,
                  height: 400,
                  bar: {groupWidth: "95%"},
                  legend: { position: "none" },
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("grafik_total2"));
                chart.draw(view, options);
            }
            </script>
            <div id="grafik_total2"></div>
            <!-- AKHIR DARI GRAFIK -->
            </th>
          </tr>


        </table>
    <!-- </div> tabbed area -->
    </div> <!-- container -->
  </div> <!-- container -->



<script type="text/javascript">
  google.charts.load('visualization', '1.0', {'packages':['corechart']});
  google.charts.setOnLoadCallback(drawChart);

  function drawChart() {

    var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Work',     11],
          ['Eat',      2],
          ['Commute',  2],
          ['Watch TV', 2],
          ['Sleep',    7]
        ]);

  var options = {
          title: 'My Daily Activities',
      backgroundColor: '#ddd',
      chartArea: {width:500,height:200}
        };

    $(".tabs a[title='content_2']").click()
    $(".tabs a[title='content_1']").click()

    var chart = new      google.visualization.PieChart(document.getElementById('chart'));

         
    chart.draw(data, options);

 var chart1= new      google.visualization.PieChart(document.getElementById('chart1'));

         
    chart1.draw(data, options);
  }





// When the document loads do everything inside here ...
    $(document).ready(function(){
    
    // When a link is clicked
    $("a.tab").click(function () {
      
      
      // switch all tabs off
      $(".active").removeClass("active");
      
      // switch this tab on
      $(this).addClass("active");
      
      // slide all content up
      $(".content").slideUp();
      
      // slide this content up
      var content_show = $(this).attr("title");
      $("#"+content_show).slideDown();
      
    });
  
    });

    function myFunction() {
    window.print();
    }

    window.onload = function() {
      myFunction();
    };

</script>


</body>
</html>