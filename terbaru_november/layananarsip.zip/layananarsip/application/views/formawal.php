<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Layanan Kearsipan</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/form-style.css">
  <link href='https://fonts.googleapis.com/css?family=Anton' rel='stylesheet'>
  <link href='https://fonts.googleapis.com/css?family=Fjalla+One' rel='stylesheet'>
</head>

<body style="background-color:#f2f2f2">
<nav class="navbar navbar-default"; style="background-color: #008CCC;">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" style="font-family: fjalla one; color: white" href="<?php echo base_url('Layanan/index2');?>">Disperpusip</a>
    </div>
  </div>
</nav>

<div class="container">
  <h2>Pendaftaran pengunjung baru</h2>
  <form class="form-horizontal" method="POST" action="<?php echo base_url('Layanan/form_daftar');?>">
    <div class="form-group">
      <label class="control-label col-sm-2" for="nama">ID Pengnjung :</label>
      <div class="col-sm-10">
        <input type="nama" class="form-control" id="id" name="id" value="<?php echo $this->session->userdata('nama');?>">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="nama">Nama Pengunjung :</label>
      <div class="col-sm-10">
        <input type="nama" class="form-control" id="nama" placeholder="Masukkan Nama Pengunjung" name="nama" required>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="ttl">TTL :</label>
      <div class="col-sm-10">          
        <input type="ttl" class="form-control" id="ttl" placeholder="Masukkan Tempat & Tanggal Lahir" name="ttl" required>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="alamat">Alamat :</label>
      <div class="col-sm-10">
        <input type="alamat" class="form-control" id="alamat" placeholder="Masukkan Alamat Asal" name="alamat" required>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="telp">Nomor Telepon :</label>
      <div class="col-sm-10">
        <input type="telp" class="form-control" id="telp" placeholder="Masukkan Nomor Telepom" name="telp" required>
      </div>
    </div>
    <div class="form-group">
	      <label class="control-label col-sm-2" for="usia">Usia :</label>
	      <div class="col-sm-3">
	      	<select name="usia" id="usia" class="form-control" style=" height:50px;" required>
	            <option selected disabled>Pilih Rentang Usia</option>
	            <option>&#8804; 15</option>
	            <option>16 - 20</option>
	            <option>21 - 25</option>
	            <option>26 - 30</option>
	            <option>31 - 35</option>
	            <option>36 - 40</option>
	            <option>41 - 45</option>
	            <option>46 - 50</option>
	            <option>51 - 55</option>
	            <option>56 - 60</option>
	            <option>&#8805; 61</option>
	        </select>
	      </div>
	      <label class="control-label col-sm-2" for="jk">Jenis Kelamin :</label>
	      <div class="col-sm-3">
	      	<select name="jk" id="jk" class="form-control" style=" height:50px;" required>
	            <option selected disabled>Pilih Jenis Kelamin</option>
	            <option>Laki-laki</option>
	            <option>Perempuan</option>
	        </select>
	      </div>          
    </div>
    <div class="form-group">
	      <label class="control-label col-sm-2" for="kewarganegaraan">Kewarganegaraan :</label>
	      <div class="col-sm-3">
	      	<select name="kewarganegaraan" id="kewarganegaraan" class="form-control" style=" height:50px;" required>
	            <option selected disabled>Pilih Kewarganegaraan</option>
	            <option>WNI</option>
	            <option>WNA</option>
	        </select>
	      </div>
	      <label class="control-label col-sm-2" for="pendidikan">Pendidikan Terakhir :</label>
	      <div class="col-sm-3">
	      	<select name="pendidikan" id="pendidikan" class="form-control" style=" height:50px;" required>
	            <option selected disabled>Pilih Pendidikan Terakhir</option>
	            <option>SMA</option>
	            <option>Diploma I - III</option>
	            <option>Sarjana / Diploma IV</option>
	            <option>Pasca Sarjana</option>
	            <option>Doktoral</option>
	        </select>
	      </div>          
    </div>
    <div class="form-group">
	      <label class="control-label col-sm-2" for="profesi">Profesi :</label>
	      <div class="col-sm-3">
	      	<select name="profesi" id="profesi" class="form-control" style=" height:50px;" required>
	            <option selected disabled>Pilih Profesi</option>
	            <option>Pelajar/Mahasiswa</option>
	            <option>Dosen</option>
	            <option>Peneliti/Sejarawan</option>
	            <option>Perusahaan/Swasta</option>
	            <option>Instansi Pemerintah Provinsi</option>
	            <option>Instansi Kabupaten/Kota</option>
	            <option>Lain-lain</option>
	        </select>
	      </div>          
    </div>
    <div class="form-group">
	      <label class="control-label col-sm-2" for="tempatstudi">Tempat Studi* :</label>
	      <div class="col-sm-5">
	      	<select name="tempatstudi" id="tempatstudi" class="form-control" style=" height:50px;">
	            <option selected disabled>Pilih Tempat Studi</option>
	            <option>Institut Teknologi Sepuluh Nopember</option>
	            <option>Universitas Airlangga</option>
	            <option>Universitas Brawijaya</option>
	            <option>Universitas Negeri Surabaya</option>
	            <option>Universitas Negeri Jember</option>
	            <option>Universitas Negeri Malang</option>
	            <option>Universitas Islam Negeri Sunan Ampel</option>
	            <option>Universitas Pembangunan Nasional</option>
	            <option>Universitas Muhammadiyah Malang</option>
	            <option>Universitas Muhammadiyah Surabaya</option>
	            <option>Universitas Muhammadiyah Sidoarjo</option>
	            <option>Lain-lain</option>
	            <option style="color:red">Non-mahasiswa</option>
	        </select>
	      </div> 
	      <h5 class="col-sm-5" style="color:red">hanya diisi pengguna berstatus mahasiswa</h5>
    </div>
    <div class="form-group">
	      <label class="control-label col-sm-2" for="prodi">Program Studi* :</label>
	      <div class="col-sm-5">
	      	<input type="prodi" class="form-control" id="prodi" placeholder="Masukkan Program Studi" name="prodi">
	      </div>
	      <h5 class="col-sm-5" style="color:red">hanya diisi pengguna berstatus mahasiswa</h5>
    </div>
        
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="button2" style="width:20%">Daftar</button>
      </div>
    </div>
  </form>
</div>

</body>
</html>