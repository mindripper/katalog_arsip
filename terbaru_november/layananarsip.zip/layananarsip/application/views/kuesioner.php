<html>
<head>
	<title> Buku Tamu Digital</title>
	<link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
  
<div class="modal-body">
      	<form method="post" role="form" id="forgotPass-form" action="<?php echo base_url("pengguna/kuesioner")?> ">
            <div class="form-group">
              	<label for="usrname">ID Anggota</label>
              	<input type="text" class="form-control" name="nama_p" id="nama_p" placeholder="Nama Peminjam" required>
            </div>
            <div class="form-group" required`> 
              	<label for="psw">Pertanyaan pertama</label><br>
              	<input type="radio" name="p1" id="p1" value="Setuju"> Setuju<br>
                <input type="radio" name="p1" id="p1" value="Bingung"> Bingung<br>
                <input type="radio" name="p1" id="p1" value="Tidak Setuju"> Tidak Setuju
            </div> 
            <div class="form-group" required>
              	<label for="psw">Pertanyaan kedua</label> <br>
              	<input type="radio" name="p2" id="p2" value="Setuju"> Setuju<br>
                <input type="radio" name="p2" id="p2" value="Bingung"> Bingung<br>
                <input type="radio" name="p2" id="p2" value="Tidak Setuju"> Tidak Setuju
            </div>
            <div class="form-group" required>
              	<label for="psw">Pertanyaan ketiga</label><br>
              	<input type="radio" name="p3" id="p3" value="Setuju"> Setuju<br>
                <input type="radio" name="p3" id="p3" value="Bingung"> Bingung<br>
                <input type="radio" name="p3" id="p3" value="Tidak Setuju"> Tidak Setuju
            </div>
            <div class="form-group" required>
              	<label for="psw">Pertanyaan keempat</label><br>
              	<input type="radio" name="p4" id="p4" value="Setuju"> Setuju<br>
                <input type="radio" name="p4" id="p4" value="Bingung"> Bingung<br>
                <input type="radio" name="p4" id="p4" value="Tidak Setuju"> Tidak Setuju
            </div>
            <button type="submit" class="btn btn-default btn-success btn-block" id="btn-send"> Kirim </button>
      	</form>
</div>
</body>
</html>