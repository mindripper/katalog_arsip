<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Layanan Kearsipan</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link href="<?php echo base_url()?>assets/css/menu-style.css" rel="stylesheet" type="text/css" >
  <link href='https://fonts.googleapis.com/css?family=Anton' rel='stylesheet'>
  <link href='https://fonts.googleapis.com/css?family=Fjalla+One' rel='stylesheet'>
</head>

<body style="background-color:#f2f2f2">
<nav class="navbar navbar-default"; style="background-color: #008CCC;">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" style="font-family: Fjalla One; color: white" href="<?php echo base_url('Layanan/index');?>">DISPERPUSIP</a>
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li onclick="document.getElementById('id01').style.display='block'" ><a style="color: white"><span class="glyphicon glyphicon-log-in" style="color: white"></span> Masuk sebagai admin</a></li>
    </ul>
  </div>
</nav>

<div class="container">
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">

      <div class="item active">
        <img src="<?php echo base_url()?>assets/img/waras1.jpg" alt="waras" style="width:100%;">
        <div class="carousel-caption">
          <h3>Tour Bus WARAS</h3>
          <p>Wisata putra-putri bangsa ke Dinas Kearsipan Jatim</p>
        </div>
      </div>

      <div class="item">
        <img src="<?php echo base_url()?>assets/img/kunjungan2.jpg" alt="kunjungan" style="width:100%;">
        <div class="carousel-caption">
          <h3>Kunjungan</h3>
          <p>Tampak dalam ruangan di Dinas Kearsipan Jatim</p>
        </div>
      </div>
    
      <div class="item">
        <img src="<?php echo base_url()?>assets/img/workshop2.jpg" alt="workshop" style="width:100%;">
        <div class="carousel-caption">
          <h3><span class="carousel-caption">Workshop</span></h3>
          <p>Sosialisasi Kearsipan oleh Arsiparis Disperpusip</p>
        </div>
      </div>
  
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

<div class="container text-center">
    <h1 style="font-size : 320%; font-family: anton;">SISTEM LAYANAN ARSIP</h1><br>
    <button class="button button1" onclick="document.getElementById('id02').style.display='block'" style="width: 30%">Isi Buku Tamu</button>
</div>

<!-- modal -->
<div id="id01" class="modal">
  <form class="modal-content animate" method="POST" action="<?php echo base_url('Admin/login');?>">
    <div class="container2">
        <label><b>Username</b></label>
        <input type="text" placeholder="Masukkan Username" name="username" required>
        <br>
        <label><b>Password</b></label>
        <input type="password" placeholder="Masukkan Password" name="password" required>
        <br>
        <button type="submit" style="width:20%">Masuk</button>
    </div>
  </form>
</div>
<!-- akhir modal -->

<!-- modal -->
<div id="id02" class="modal">
  <form class="modal-content animate" method="POST" action ="<?php echo base_url('layanan/menu_masuk');?>">
    <div class="container2">
        <form>
            <div class="form-group">
                <select name="select1" id="select1" class="form-control" style=" height:50px;">
                    <option selected disabled>Pilih Jenis Nomor Identitas</option>
                    <option>KTP</option>
                    <option>KTM</option>
                    <option>SIM</option>
                    <option>Paspor</option>
                    <option>Surat Keterangan Penelitian</option> 
                </select>
            </div>
        </form>
        <input type="text" placeholder="Masukkan Nomor Identitas" name="no_id" required>
        <br>
        <button type="submit">Masuk</button>
    </div>
  </form>
</div>
<!-- akhir modal -->


<script>
    var modal = document.getElementById('id01');
    var modal2 = document.getElementById('id02');
    window.onclick = function(event) 
        {
            if (event.target == modal)
            {
                modal.style.display = "none";
            }
            else if
            (event.target == modal2)
            {
                modal2.style.display = "none";
            } 
        };
</script>
</body>
</html>
