<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Layanan Kearsipan</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link href="<?php echo base_url()?>assets/css/menu-style.css" rel="stylesheet" type="text/css" >
</head>

<body style="background-color:#f2f2f2">
<!-- perhitungan keperluan kunjungan -->
  <?php
  $flag=1;
  foreach ($k1 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $a1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $a1=0;
  ?>

  <?php
  $flag=1;
  foreach ($k1 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $a2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $a2=0;
  ?>

  <?php
  $flag=1;
  foreach ($k1 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $a3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $a3=0;
  ?>

  <?php
  $flag=1;
  foreach ($k1 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $a4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $a4=0;
  ?>

  <?php
  $flag=1;
  foreach ($k1 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $a5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $a5=0;
  ?>

  <?php
  $flag=1;
  foreach ($k2 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $b1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $b1=0;
  ?>

  <?php
  $flag=1;
  foreach ($k2 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $b2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $b2=0;
  ?>

  <?php
  $flag=1;
  foreach ($k2 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $b3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $b3=0;
  ?>

  <?php
  $flag=1;
  foreach ($k2 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $b4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $b4=0;
  ?>

  <?php
  $flag=1;
  foreach ($k2 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $b5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $b5=0;
  ?>

  <?php
  $flag=1;
  foreach ($k3 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $c1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $c1=0;
  ?>

  <?php
  $flag=1;
  foreach ($k3 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $c2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $c2=0;
  ?>

  <?php
  $flag=1;
  foreach ($k3 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $c3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $c3=0;
  ?>

  <?php
  $flag=1;
  foreach ($k3 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $c4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $c4=0;
  ?>

  <?php
  $flag=1;
  foreach ($k3 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $c5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $c5=0;
  ?>

  <?php
  $flag=1;
  foreach ($k4 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $d1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $d1=0;
  ?>

   <?php
  $flag=1;
  foreach ($k4 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $d2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $d2=0;
  ?>

   <?php
  $flag=1;
  foreach ($k4 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $d3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $d3=0;
  ?>

   <?php
  $flag=1;
  foreach ($k4 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $d4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $d4=0;
  ?>

   <?php
  $flag=1;
  foreach ($k4 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $d5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $d5=0;
  ?>

   <?php
  $flag=1;
  foreach ($k5 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $e1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $e1=0;
  ?>

  <?php
  $flag=1;
  foreach ($k5 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $e2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $e2=0;
  ?>

  <?php
  $flag=1;
  foreach ($k5 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $e3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $e3=0;
  ?>

  <?php
  $flag=1;
  foreach ($k5 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $e4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $e4=0;
  ?>

  <?php
  $flag=1;
  foreach ($k5 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $e5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $e5=0;
  ?>

  <?php
  $flag=1;
  foreach ($k6 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $f1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $f1=0;
  ?>

  <?php
  $flag=1;
  foreach ($k6 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $f2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $f2=0;
  ?>

  <?php
  $flag=1;
  foreach ($k6 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $f3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $f3=0;
  ?>

  <?php
  $flag=1;
  foreach ($k6 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $f4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $f4=0;
  ?>

  <?php
  $flag=1;
  foreach ($k6 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $f5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $f5=0;
  ?>

  <?php
  $flag=1;
  foreach ($k7 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $g1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $g1=0;
  ?>

  <?php
  $flag=1;
  foreach ($k7 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $g2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $g2=0;
  ?>

  <?php
  $flag=1;
  foreach ($k7 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $g3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $g3=0;
  ?>

  <?php
  $flag=1;
  foreach ($k7 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $g4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $g4=0;
  ?>

  <?php
  $flag=1;
  foreach ($k7 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $g5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $g5=0;
  ?>

  <?php
  $flag=1;
  foreach ($k8 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $h1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $h1=0;
  ?>

  <?php
  $flag=1;
  foreach ($k8 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $h2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $h2=0;
  ?>

  <?php
  $flag=1;
  foreach ($k8 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $h3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $h3=0;
  ?>

  <?php
  $flag=1;
  foreach ($k8 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $h4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $h4=0;
  ?>

  <?php
  $flag=1;
  foreach ($k8 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $h5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $h5=0;
  ?>

  <?php
  $flag=1;
  foreach ($k9 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $i1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $i1=0;
  ?>

  <?php
  $flag=1;
  foreach ($k9 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $i2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $i2=0;
  ?>

  <?php
  $flag=1;
  foreach ($k9 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $i3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $i3=0;
  ?>

  <?php
  $flag=1;
  foreach ($k9 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $i4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $i4=0;
  ?>

  <?php
  $flag=1;
  foreach ($k9 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $i5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $i5=0;
  ?>

  <?php
  $flag=1;
  foreach ($k10 as $tmp) {
    if($tmp->jawaban1 == 'STS'){
     $j1=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $j1=0;
  ?>

  <?php
  $flag=1;
  foreach ($k10 as $tmp) {
    if($tmp->jawaban1 == 'TS'){
     $j2=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $j2=0;
  ?>

  <?php
  $flag=1;
  foreach ($k10 as $tmp) {
    if($tmp->jawaban1 == 'R'){
     $j3=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $j3=0;
  ?>

  <?php
  $flag=1;
  foreach ($k10 as $tmp) {
    if($tmp->jawaban1 == 'S'){
     $j4=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $j4=0;
  ?>

  <?php
  $flag=1;
  foreach ($k10 as $tmp) {
    if($tmp->jawaban1 == 'SS'){
     $j5=$tmp->jawab_ss;
     $flag = 0;
    }
  }
  if($flag) $j5=0;
  ?>

  <?php
  $jumlah1=$a1+$a2+$a3+$a4+$a5;
  $jumlah2=$b1+$b2+$b3+$b4+$b5;
  $jumlah3=$c1+$c2+$c3+$c4+$c5;
  $jumlah4=$d1+$d2+$d3+$d4+$d5;
  $jumlah5=$e1+$e2+$e3+$e4+$e5;
  $jumlah6=$f1+$f2+$f3+$f4+$f5;
  $jumlah7=$g1+$g2+$g3+$g4+$g5;
  $jumlah8=$h1+$h2+$h3+$h4+$h5;
  $jumlah9=$i1+$i2+$i3+$i4+$i5;
  $jumlah10=$j1+$j2+$j3+$j4+$j5;
  echo $jumlah1, 'ea', $jumlah2, 'ea'. $jumlah3, 'ea',$jumlah4, 'ea',$jumlah5, 'ea';
  echo $jumlah6, 'ea', $jumlah7, 'ea'. $jumlah8, 'ea',$jumlah9, 'ea',$jumlah10, 'ea';
  ?>
  </body>
  </html>