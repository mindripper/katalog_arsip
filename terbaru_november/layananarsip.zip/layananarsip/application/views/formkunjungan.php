<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Layanan Kearsipan</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/form-style.css">
  <link href='https://fonts.googleapis.com/css?family=Anton' rel='stylesheet'>
  <link href='https://fonts.googleapis.com/css?family=Fjalla+One' rel='stylesheet'>
</head>

<body style="background-color:#f2f2f2">
<nav class="navbar navbar-default"; style="background-color: #008CCC;">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" style="font-family: fjalla one; color: white" href="<?php echo base_url('Layanan/index2');?>">Disperpusip</a>
    </div>
  </div>
</nav>

<div class="container" style="text-align:center;">
  <h2 style="font-family:anton;">Selamat datang, <?php echo $this->session->userdata('nama');?></h2>
  <img src="<?php echo base_url()?>assets/img/akun.png"  style="width:120px; height: auto;">
  <h2 style="font-family:anton;">Apa yang Anda cari?</h2>
</div>
<div class="container">
  <form class="form-horizontal" method="POST" action="<?php echo base_url('Layanan/form_kunjungan')?>">
  <div class="form-group">
        <label class="control-label col-sm-2" for="kepentingan">Keperluan Pengguna :</label>
        <div class="col-sm-3">
          <select name="kepentingan" id="kepentingan" class="form-control" style=" height:50px;" required>
              <option selected disabled>Pilih Keperluan Anda</option>
              <option>Penulisan Skripsi/Tesis/Disertasi</option>
              <option>Penulisan Tugas Kuliah</option>
              <option>Pembukttian Hukum</option>
              <option>Penulisan Sejarah</option>
              <option>Penelusuran Silsilah Keluarga</option>
              <option>Kedinasan</option>
              <option>Lain-lain</option>
          </select>
        </div> 
        <label class="control-label col-sm-3" for="fokus">Fokus Penelitian :</label>
        <div class="col-sm-3">
          <select name="fokus" id="fokus" class="form-control" style=" height:50px;" required>
              <option selected disabled>Pilih Fokus Penelitian</option>
              <option>Arsip sebelum 1900</option>
              <option>Arsip 1901 - 1945</option>
              <option>Arsip 1946 - 1965</option>
              <option>Arsip 1966 - 1985</option>
              <option>Arsip 1986 - Sekarang</option>
          </select>
        </div>         
  </div>
  <div class="form-group">
        <label class="control-label col-sm-2" for="kategorii">Kategori yang dicari:</label>
        <div class="col-sm-3">
          <select name="kategorii" id="kategorii" class="form-control" style=" height:50px;" required>
              <option selected disabled>Pilih Kategori Arsip yang dicari</option>
              <option>Umum</option>
              <option>Secretary Oost Java</option>
              <option>Lembaga Vertikal</option>
              <option>Organisasi Perangkat Daerah</option>
              <option>BUMN</option>
              <option>Arsip Perseorangan</option>
              <option>Lain-lain</option>
          </select>
        </div> 
      
        <label class="control-label col-sm-3" for="media">Media yang dicari :</label>
        <div class="col-sm-3">
          <select name="media" id="media" class="form-control" style=" height:50px;" required>
              <option selected disabled>Pilih Media Arsip yang dicari</option>
              <option>Kertas</option>
              <option>Foto</option>
              <option>Film</option>
              <option>Kaset</option>
              <option>Peta</option>
              <option>Media Lain</option>
          </select>
        </div>         
  </div>
  <div class="form-group">
        <label class="control-label col-sm-2" for="kunjungan">Jumlah Kunjungan :</label>
        <div class="col-sm-3">
          <select name="kunjungan" id="kunjungan" class="form-control" style=" height:50px;" required>
              <option selected disabled>Pilih Jumlah Kunjungan</option>
              <option>Pertama kali</option>
              <option>2 kali</option>
              <option>3 kali</option>
              <option>4 kali</option>
              <option>&#8805; 5 kali</option>
          </select>
        </div> 
        <label class="control-label col-sm-3" for="media">Proyeksi Penelitian :</label>
        <div class="col-sm-3">
          <select name="proyeksi" id="proyeksi" class="form-control" style=" height:50px;" required>
              <option selected disabled>Pilih Jangka Waktu Proyeksi</option>
              <option>1 - 2 hari</option>
              <option>3 - 4 hari</option>
              <option>5 - 6 hari</option>
              <option>&#8805; 7 hari</option>
          </select>
        </div>         
  </div>
  <div class="form-group">        
    <div class="col-sm-2"> <input type="hidden" class="form-control" id="no_id"  name="no_id" value="<?php echo $this->session->userdata('id');?>"></div>
    <div class="col-sm-9">
      <button type="submit" class="button2" style="width:100%">Submit</button>
    </div>
  </div>
</div>

</body>
</html>