<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Layanan Kearsipan</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/menu-style.css">
  <link href='https://fonts.googleapis.com/css?family=Anton' rel='stylesheet'>
  <link href='https://fonts.googleapis.com/css?family=Fjalla+One' rel='stylesheet'>
</head>

<body style="background-color:#f2f2f2">
<nav class="navbar navbar-default"; style="background-color: #008CCC;">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" style="font-family: fjalla one; color: white" href="<?php echo base_url('Layanan/index2');?>">Disperpusip</a>
    </div>
  </div>
</nav>

<div class="container">
  <h2 style="font-family: anton; text-align:center">Kuisioner</h2>  
  <h3 style="font-family: anton; text-align:center">Isilah kuisioner berikut ini berdasarkan tingkat keyakinan <br>(STS)=Sangat Tidak Setuju (TS)=Tidak Setuju (R)=Ragu-ragu (S)=Setuju (SS)=Sangat Setuju</h3><br>

<div class="container" style="background-color: white; padding-left: 10%; padding-top:5%">
<h4 style="font-weight: 900">Bagian 8 : Fasilitas Referensi Pendukung Layanan<h4>  
  <form method="POST" class="form-horizontal" action="<?php echo base_url('Layanan/kuesioner8')?>">
  <div class="form-group">
        <h4>1.  Memiliki buku-buku referensi pendukung layanan</h4>
        <div class="row">
          <div class="col-sm-2">
            <input type="radio" name="question-1-answers" value="STS" />
            <label> STS </label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-1-answers" value="TS" />
            <label> TS</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-1-answers" value="R" />
            <label> R</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-1-answers" value="S" />
            <label> S</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-1-answers" value="SS" required/>
            <label> SS</label></div>
        </div>
  </div>
  <div class="form-group">
        <h4>2.  Buku referensi yang tersedia mendukung layanan penelusuran sumber arsip</h4>
        <div class="row">
          <div class="col-sm-2">
            <input type="radio" name="question-2-answers" value="STS" />
            <label> STS </label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-2-answers" value="TS" />
            <label> TS</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-2-answers" value="R" />
            <label> R</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-2-answers" value="S" />
            <label> S</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-2-answers" value="SS" required/>
            <label> SS</label></div>
        </div>
  </div>
  <div class="form-group">
        <h4>3.  Buku referensi pendukung layanan memenuhi harapan pengguna arsip</h4>
        <div class="row">
          <div class="col-sm-2">
            <input type="radio" name="question-3-answers" value="STS" />
            <label> STS </label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-3-answers" value="TS" />
            <label> TS</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-3-answers" value="R" />
            <label> R</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-3-answers" value="S" />
            <label> S</label></div>
          <div class="col-sm-2">
            <input type="radio" name="question-3-answers" value="SS" required/>
            <label> SS</label></div>
        </div>
  </div>
    <div class="row">
      <div class="col-sm-8"><input type="hidden" class="form-control" id="no_id"  name="no_id" value="<?php echo $this->session->userdata('id');?>"></div>
      <div class="col-sm-3">
        <button type="submit" >Selanjutnya</button>
      </div>
    </div>
</div>

</body>
</html>