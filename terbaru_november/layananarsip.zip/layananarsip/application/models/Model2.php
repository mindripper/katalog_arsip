<?php  
  class Model2 extends CI_Model{

     function login($username, $password) {
        $query = $this->db->query("SELECT * FROM user WHERE username='".$username."' AND password='".$password."' ");

        return $query->result();
    }

   public function get_usia(){
    $query=$this->db->query("SELECT umur_anggota, count(*) as jumlah_usia from anggota GROUP BY umur_anggota");
    return $query->result();
   }

    public function get_jk(){
    $query=$this->db->query("SELECT jk_anggota, count(*) as jumlah_jk from anggota GROUP BY jk_anggota");
    return $query->result();
   }

   public function get_kwn(){
    $query=$this->db->query("SELECT kewarganegaraan_anggota, count(*) as jumlah_kwn from anggota GROUP BY kewarganegaraan_anggota");
    return $query->result();
   }

   public function get_pt(){
    $query=$this->db->query("SELECT pendidikan_pengguna, count(*) as jumlah_pt from anggota GROUP BY pendidikan_pengguna");
    return $query->result();
   }

   public function get_prof(){
    $query=$this->db->query("SELECT profesi_pengguna, count(*) as jumlah_prof from anggota GROUP BY profesi_pengguna");
    return $query->result();
   }

   public function get_ts(){
    $query=$this->db->query("SELECT tempat_studi, count(*) as jumlah_ts from anggota GROUP BY tempat_studi");
    return $query->result();
   }

   
   public function kunj_kep($month, $year){
    $query=$this->db->query("SELECT keperluan_kunjungan, COUNT(*) AS jumlah_kk FROM kunjungan WHERE MONTH(tanggal)='".$month."' AND YEAR(tanggal)='".$year."' GROUP BY keperluan_kunjungan");
   return $query->result();
   }

   public function kunj_fokus($month, $year){
    $query=$this->db->query("SELECT fokus_kunjungan, COUNT(*) AS jumlah_kf FROM kunjungan WHERE MONTH(tanggal)='".$month."' AND YEAR(tanggal)='".$year."' GROUP BY fokus_kunjungan");
   return $query->result();
   }

   public function kunj_media($month, $year){
    $query=$this->db->query("SELECT media_kunjungan, COUNT(*) AS jumlah_km FROM kunjungan WHERE MONTH(tanggal)='".$month."' AND YEAR(tanggal)='".$year."' GROUP BY media_kunjungan");
   return $query->result();
   }

   public function kunj_kategori($month, $year){
    $query=$this->db->query("SELECT kategori_kunjungan, COUNT(*) AS jumlah_kat FROM kunjungan WHERE MONTH(tanggal)='".$month."' AND YEAR(tanggal)='".$year."' GROUP BY kategori_kunjungan");
   return $query->result();
   }

   public function kunj_jumlah($month, $year){
    $query=$this->db->query("SELECT jumlah_kunjungan, COUNT(*) AS jumlah_kj FROM kunjungan WHERE MONTH(tanggal)='".$month."' AND YEAR(tanggal)='".$year."' GROUP BY jumlah_kunjungan");
   return $query->result();
   }

   public function kunj_proyeksi($month, $year){
    $query=$this->db->query("SELECT proyeksi_kunjungan, COUNT(*) AS jumlah_kp FROM kunjungan WHERE MONTH(tanggal)='".$month."' AND YEAR(tanggal)='".$year."' GROUP BY proyeksi_kunjungan");
   return $query->result();
   }

    public function jumlah1($month, $year){
      $querya1 = $this->db->query("SELECT jawaban1, COUNT(*) AS jawab_ss FROM (SELECT jawaban1 , tanggal FROM (
                SELECT jawaban1, tanggal FROM kategori1
                UNION ALL
                SELECT jawaban2, tanggal FROM kategori1
                UNION ALL
                SELECT jawaban3,tanggal FROM kategori1
                UNION ALL
                SELECT jawaban4, tanggal FROM kategori1
                UNION ALL
                SELECT jawaban5, tanggal FROM kategori1) jawaban
                WHERE MONTH (tanggal)='".$month."' AND YEAR (tanggal)='".$year."') jawaban_2 GROUP BY jawaban1");

      return $querya1->result();
    }

    public function jumlah2($month, $year){
      $querya1 = $this->db->query("SELECT jawaban1, COUNT(*) AS jawab_ss FROM (SELECT jawaban1 , tanggal FROM (
                SELECT jawaban1,tanggal FROM kategori2
                UNION ALL
                SELECT jawaban2,tanggal FROM kategori2
                UNION ALL
                SELECT jawaban3,tanggal FROM kategori2
                UNION ALL
                SELECT jawaban4,tanggal FROM kategori2
                UNION ALL
                SELECT jawaban5,tanggal FROM kategori2
                UNION ALL
                SELECT jawaban6,tanggal FROM kategori2
                UNION ALL
                SELECT jawaban7,tanggal FROM kategori2
                UNION ALL
                SELECT jawaban8,tanggal FROM kategori2
                UNION ALL
                SELECT jawaban9,tanggal FROM kategori2
                UNION ALL
                SELECT jawaban10,tanggal FROM kategori2
                UNION ALL
                SELECT jawaban11,tanggal FROM kategori2
                UNION ALL
                SELECT jawaban12,tanggal FROM kategori2
                UNION ALL
                SELECT jawaban13,tanggal FROM kategori2) jawaban
                WHERE MONTH (tanggal)='".$month."' AND YEAR (tanggal)='".$year."')jawaban_2 GROUP BY jawaban1");

      return $querya1->result();
    }

    public function jumlah3($month, $year){
      $querya1 = $this->db->query("SELECT jawaban1, COUNT(*) AS jawab_ss FROM (SELECT jawaban1 , tanggal FROM (
                SELECT jawaban1, tanggal FROM kategori3
                UNION ALL
                SELECT jawaban2, tanggal FROM kategori3
                UNION ALL
                SELECT jawaban3,tanggal FROM kategori3
                UNION ALL
                SELECT jawaban4, tanggal FROM kategori3
                UNION ALL
                SELECT jawaban5, tanggal FROM kategori3
                UNION ALL
                SELECT jawaban6, tanggal FROM kategori3
                UNION ALL
                SELECT jawaban7, tanggal FROM kategori3
                UNION ALL
                SELECT jawaban8, tanggal FROM kategori3
                UNION ALL
                SELECT jawaban9, tanggal FROM kategori3) jawaban
                WHERE MONTH (tanggal)='".$month."' AND YEAR (tanggal)='".$year."') jawaban_2 GROUP BY jawaban1");

      return $querya1->result();
    }

    public function jumlah4($month, $year){
      $querya1 = $this->db->query("SELECT jawaban1, COUNT(*) AS jawab_ss FROM (SELECT jawaban1 , tanggal FROM (
                SELECT jawaban1, tanggal FROM kategori4
                UNION ALL
                SELECT jawaban2, tanggal FROM kategori4
                UNION ALL
                SELECT jawaban3,tanggal FROM kategori4
                UNION ALL
                SELECT jawaban4, tanggal FROM kategori4) jawaban
                WHERE MONTH (tanggal)='".$month."' AND YEAR (tanggal)='".$year."') jawaban_2 GROUP BY jawaban1");

      return $querya1->result();
    }

    public function jumlah5($month, $year){
      $querya1 = $this->db->query("SELECT jawaban1, COUNT(*) AS jawab_ss FROM (SELECT jawaban1 , tanggal FROM (
                SELECT jawaban1, tanggal FROM kategori5
                UNION ALL
                SELECT jawaban2, tanggal FROM kategori5
                UNION ALL
                SELECT jawaban3,tanggal FROM kategori5
                UNION ALL
                SELECT jawaban4, tanggal FROM kategori5
                UNION ALL
                SELECT jawaban5, tanggal FROM kategori5
                UNION ALL
                SELECT jawaban6, tanggal FROM kategori5
                UNION ALL
                SELECT jawaban7, tanggal FROM kategori5
                UNION ALL
                SELECT jawaban8, tanggal FROM kategori5
                UNION ALL
                SELECT jawaban9, tanggal FROM kategori5
                UNION ALL
                SELECT jawaban10, tanggal FROM kategori5
                UNION ALL
                SELECT jawaban11, tanggal FROM kategori5) jawaban
                WHERE MONTH (tanggal)='".$month."' AND YEAR (tanggal)='".$year."') jawaban_2 GROUP BY jawaban1");

      return $querya1->result(); //sampe 11
    }

    public function jumlah6($month, $year){
      $querya1 = $this->db->query("SELECT jawaban1, COUNT(*) AS jawab_ss FROM (SELECT jawaban1 , tanggal FROM (
                SELECT jawaban1, tanggal FROM kategori6
                UNION ALL
                SELECT jawaban2, tanggal FROM kategori6
                UNION ALL
                SELECT jawaban3,tanggal FROM kategori6
                UNION ALL
                SELECT jawaban4, tanggal FROM kategori6) jawaban
                WHERE MONTH (tanggal)='".$month."' AND YEAR (tanggal)='".$year."') jawaban_2 GROUP BY jawaban1");

      return $querya1->result(); //sampe 4
    }

    public function jumlah7($month, $year){
      $querya1 = $this->db->query("SELECT jawaban1, COUNT(*) AS jawab_ss FROM (SELECT jawaban1 , tanggal FROM (
                SELECT jawaban1, tanggal FROM kategori7
                UNION ALL
                SELECT jawaban2, tanggal FROM kategori7
                UNION ALL
                SELECT jawaban3,tanggal FROM kategori7
                UNION ALL
                SELECT jawaban4, tanggal FROM kategori7
                UNION ALL
                SELECT jawaban5, tanggal FROM kategori7
                UNION ALL
                SELECT jawaban6, tanggal FROM kategori7
                UNION ALL
                SELECT jawaban7, tanggal FROM kategori7
                UNION ALL
                SELECT jawaban8, tanggal FROM kategori7
                UNION ALL
                SELECT jawaban9, tanggal FROM kategori7
                UNION ALL
                SELECT jawaban10, tanggal FROM kategori7
                UNION ALL
                SELECT jawaban11, tanggal FROM kategori7
                UNION ALL
                SELECT jawaban12, tanggal FROM kategori7
                UNION ALL
                SELECT jawaban13, tanggal FROM kategori7
                UNION ALL
                SELECT jawaban14, tanggal FROM kategori7
                UNION ALL
                SELECT jawaban15, tanggal FROM kategori7) jawaban
                WHERE MONTH (tanggal)='".$month."' AND YEAR (tanggal)='".$year."') jawaban_2 GROUP BY jawaban1");

      return $querya1->result(); //sampe 15
    }

    public function jumlah8($month, $year){
      $querya1 = $this->db->query("SELECT jawaban1, COUNT(*) AS jawab_ss FROM (SELECT jawaban1 , tanggal FROM (
                SELECT jawaban1, tanggal FROM kategori8
                UNION ALL
                SELECT jawaban2, tanggal FROM kategori8
                UNION ALL
                SELECT jawaban3,tanggal FROM kategori8) jawaban
                WHERE MONTH (tanggal)='".$month."' AND YEAR (tanggal)='".$year."') jawaban_2 GROUP BY jawaban1");

      return $querya1->result(); //sampe 3
    }

    public function jumlah9($month, $year){
      $querya1 = $this->db->query("SELECT jawaban1, COUNT(*) AS jawab_ss FROM (SELECT jawaban1 , tanggal FROM (
                SELECT jawaban1, tanggal FROM kategori9
                UNION ALL
                SELECT jawaban2, tanggal FROM kategori9
                UNION ALL
                SELECT jawaban3,tanggal FROM kategori9
                UNION ALL
                SELECT jawaban4, tanggal FROM kategori9
                UNION ALL
                SELECT jawaban5, tanggal FROM kategori9
                 UNION ALL
                SELECT jawaban6, tanggal FROM kategori9
                 UNION ALL
                SELECT jawaban7, tanggal FROM kategori9
                 UNION ALL
                SELECT jawaban8, tanggal FROM kategori9
                 UNION ALL
                SELECT jawaban9, tanggal FROM kategori9) jawaban
                WHERE MONTH (tanggal)='".$month."' AND YEAR (tanggal)='".$year."') jawaban_2 GROUP BY jawaban1");

      return $querya1->result(); //sampe 9
    }

    public function jumlah10($month, $year){
      $querya1 = $this->db->query("SELECT jawaban1, COUNT(*) AS jawab_ss FROM (SELECT jawaban1 , tanggal FROM (
                SELECT jawaban1, tanggal FROM kategori10
                UNION ALL
                SELECT jawaban2, tanggal FROM kategori10
                UNION ALL
                SELECT jawaban3,tanggal FROM kategori10) jawaban
                WHERE MONTH (tanggal)='".$month."' AND YEAR (tanggal)='".$year."') jawaban_2 GROUP BY jawaban1");

      return $querya1->result(); //sampe3
    }
  }
?>