<?php  
  class M_tampil extends CI_Model{  
   function __construct(){  
    parent::__construct();  
    $this->load->database();  
   }  
   function m_lihat(){  
    $lihat = $this->db->get('phonebook');  
    return $lihat->result();  
   }  
  }  
  ?>  