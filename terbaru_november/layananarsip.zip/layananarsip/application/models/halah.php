cari jk

SELECT tabel1.jk_anggota, tabel2.jumlah
FROM (SELECT jk_anggota, 0 AS jumlah FROM(
SELECT 'L' AS jk_anggota
UNION ALL
SELECT 'P' AS jk_anggota) umur
GROUP BY jk_anggota) tabel1
LEFT JOIN (SELECT jk_anggota, COUNT(*) AS jumlah FROM(
SELECT * FROM anggota WHERE jk_anggota='L'
UNION ALL
SELECT * FROM anggota WHERE jk_anggota='P') umur
GROUP BY jk_anggota) tabel2 
ON tabel1.jk_anggota = tabel2.jk_anggota

cari kewarganegaraan

SELECT tabel1.kewarganegaraan_anggota, tabel2.jumlah
FROM (SELECT kewarganegaraan_anggota, 0 AS jumlah FROM(
SELECT 'L' AS kewarganegaraan_anggota
UNION ALL
SELECT 'P' AS kewarganegaraan_anggota) umur
GROUP BY kewarganegaraan_anggota) tabel1
LEFT JOIN (SELECT kewarganegaraan_anggota, COUNT(*) AS jumlah FROM(
SELECT * FROM anggota WHERE kewarganegaraan_anggota='L'
UNION ALL
SELECT * FROM anggota WHERE kewarganegaraan_anggota='P') umur
GROUP BY kewarganegaraan_anggota) tabel2 
ON tabel1.kewarganegaraan_anggota = tabel2.kewarganegaraan_anggota

pendidikan terakhir

SELECT tabel1.pendidikan_pengguna, tabel2.jumlah
FROM (SELECT pendidikan_pengguna, 0 AS jumlah FROM(
SELECT 'SMA' AS pendidikan_pengguna
UNION ALL
SELECT 'Diploma I - III' AS pendidikan_pengguna
UNION ALL
SELECT 'Sarjana / Diploma IV' AS pendidikan_pengguna
UNION ALL
SELECT 'Pasca Sarjana' AS pendidikan_pengguna
UNION ALL
SELECT 'Doktoral' AS pendidikan_pengguna) umur
GROUP BY pendidikan_pengguna) tabel1
LEFT JOIN (SELECT pendidikan_pengguna, COUNT(*) AS jumlah FROM(
SELECT * FROM anggota WHERE pendidikan_pengguna='SMA'
UNION ALL
SELECT * FROM anggota WHERE pendidikan_pengguna='Diploma I - III'
UNION ALL
SELECT * FROM anggota WHERE pendidikan_pengguna='Sarjana / Diploma IV'
UNION ALL
SELECT * FROM anggota WHERE pendidikan_pengguna='Pasca Sarjana'
UNION ALL
SELECT * FROM anggota WHERE pendidikan_pengguna='Doktoral') umur
GROUP BY pendidikan_pengguna) tabel2 
ON tabel1.pendidikan_pengguna = tabel2.pendidikan_pengguna

profesi_pengguna 

SELECT tabel1.profesi_pengguna, tabel2.jumlah
FROM (SELECT profesi_pengguna, 0 AS jumlah FROM(
SELECT 'Pelajar/Mahasiswa' AS profesi_pengguna
UNION ALL
SELECT 'Dosen' AS profesi_pengguna
UNION ALL
SELECT 'Peneliti/Sejarawan' AS profesi_pengguna
UNION ALL
SELECT 'Perusahaan/Swasta' AS profesi_pengguna
UNION ALL
SELECT 'Instansi Pemerintah Provinsi' AS profesi_pengguna
UNION ALL
SELECT 'Instansi Pemerintah Kabupaten' AS profesi_pengguna
UNION ALL
SELECT 'Lain-lain' AS profesi_pengguna) umur
GROUP BY profesi_pengguna) tabel1
LEFT JOIN (SELECT profesi_pengguna, COUNT(*) AS jumlah FROM(
SELECT * FROM anggota WHERE profesi_pengguna='Pelajar/Mahasiswa'
UNION ALL
SELECT * FROM anggota WHERE profesi_pengguna='Dosen'
UNION ALL
SELECT * FROM anggota WHERE profesi_pengguna='Peneliti/Sastrawan'
UNION ALL
SELECT * FROM anggota WHERE profesi_pengguna='Perusahaan/Swasta'
UNION ALL
SELECT * FROM anggota WHERE profesi_pengguna='Instansi Pemerintah Provinsi'
UNION ALL
SELECT * FROM anggota WHERE profesi_pengguna='Instansi Pemerintah Kabupaten'
UNION ALL
SELECT * FROM anggota WHERE profesi_pengguna='Lain-lain') umur
GROUP BY profesi_pengguna) tabel2 
ON tabel1.profesi_pengguna = tabel2.profesi_pengguna

tempat_Studi

SELECT tabel1.tempat_studi, tabel2.jumlah
FROM (SELECT profesi_pengguna, 0 AS jumlah FROM(
SELECT '' AS tempat_studi
UNION ALL
SELECT 'Dosen' AS tempat_studi
UNION ALL
SELECT 'Peneliti/Sejarawan' AS tempat_studi
UNION ALL
SELECT 'Perusahaan/Swasta' AS tempat_studi
UNION ALL
SELECT 'Instansi Pemerintah Provinsi' AS tempat_studi
UNION ALL
SELECT 'Instansi Pemerintah Kabupaten' AS tempat_studi
UNION ALL
SELECT 'Lain-lain' AS tempat_studi) umur
GROUP BY tempat_studi) tabel1
LEFT JOIN (SELECT tempat_studi, COUNT(*) AS jumlah FROM(
SELECT * FROM anggota WHERE tempat_studi='Pelajar/Mahasiswa'
UNION ALL
SELECT * FROM anggota WHERE tempat_studi='Dosen'
UNION ALL
SELECT * FROM anggota WHERE tempat_studi='Peneliti/Sastrawan'
UNION ALL
SELECT * FROM anggota WHERE tempat_studi='Perusahaan/Swasta'
UNION ALL
SELECT * FROM anggota WHERE tempat_studi='Instansi Pemerintah Provinsi'
UNION ALL
SELECT * FROM anggota WHERE tempat_studi='Instansi Pemerintah Kabupaten'
UNION ALL
SELECT * FROM anggota WHERE tempat_studi='Lain-lain') umur
GROUP BY tempat_studi) tabel2 
ON tabel1.tempat_studi = tabel2.tempat_studi

