<?php  
  class Models extends CI_Model{

  	public function masuk($id){
  		$query = $this->db->query("SELECT * FROM anggota WHERE identitas_pengguna='".$id."'");
        return $query->result();
  	}

    public function login($username, $password){
      $query = $this->db->query("SELECT * FROM user WHERE username='".$username."' AND password='".$password."'");
        return $query->result();
    }

  	function input_biodata ($data)
		{
			$query = $this->db->insert('anggota', $data);
			
			return $query->result_array();
		}

  }